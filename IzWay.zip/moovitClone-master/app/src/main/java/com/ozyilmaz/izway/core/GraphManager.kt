package com.ozyilmaz.izway

import android.content.Context
import android.location.Address
import android.location.Geocoder
import com.ozyilmaz.izway.core.*
import io.reactivex.Observable
import java.io.IOException
import java.util.stream.Collectors


class GraphManager(context: Context) {
    var graph = Graph(false)
    var graphMap = HashMap<Int, Vertex>()
    var stations = ArrayList<Station>()
    var context = context
    var dataUtil = DataUtil()

    fun generateGraphFromMockData() {
        graph = MockGraphData.insertVertices(graph)
        graph = MockGraphData.createAllEdgesToGraph(graph)
    }


    fun find(
        sourceLat: Double,
        sourceLongi: Double,
        destiLat: Double,
        destiLongi: Double
    ): Pair<ArrayList<Int>, ArrayList<Int>> {
        var sourceInRange: ArrayList<Int> = arrayListOf()
        var destinationInRange: ArrayList<Int> = arrayListOf()

        stations.parallelStream().forEach { it ->

            if (graph.vertices.find { o -> o.id == it.id } != null) {
                var sourceDist = distance(sourceLat, sourceLongi, it.latitude, it.longitude)
                if (sourceDist < 0.7) {
                    sourceInRange.add(it.id)
                }

                var destDist = distance(destiLat, destiLongi, it.latitude, it.longitude)
                if (destDist < 0.7) {
                    destinationInRange.add(it.id)
                }
            }

        }
        return Pair(sourceInRange, destinationInRange)
    }


    fun updateData(): Observable<Boolean> {
        getAllVertexLocation()
        dataUtil.syncToCloudPointData(stations)
        dataUtil.retrieveDataFromCloud()
            .subscribe { o ->
                stations = o
                return@subscribe
            }

        return Observable.just(true)
    }

    fun prepareGraph(): Observable<Boolean> {
        generateGraphFromMockData()
        dataUtil.retrieveDataFromCloud()
            .subscribe { o ->
                stations = o
            }
        return Observable.just(true)
    }

    //Just First Time
    private fun getAllVertexLocation() {
        graph.vertices.parallelStream().forEach { it ->
            var latLong = searchLocation(it.name, it.type)
            var station = Station.from(it, latLong.first, latLong.second)
            stations.add(station)
        }
        stations.sortBy { o -> o.id }
    }

    fun process(
        lat1: Double?,
        lon1: Double?,
        destination: String
    ): Observable<ArrayList<String>>? {
        var destinationLoc = searchLocation(destination, null)
        var result = ArrayList<kotlin.String>()

        if (destinationLoc.first == null || destinationLoc.second == null) {
            for (i in 0..10) {
                destinationLoc = searchLocation(destination, null)
                println("Researching Destination agin $i")
            }
        }

        val lat2 = destinationLoc.first
        val lon2 = destinationLoc.second

        if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) {
            var result = ArrayList<String>()
            result.add("No Options")
            result.add("No Options")
            result.add("No Options")
            return Observable.just(result)
        }

        println("""Process Started : Destination: ${destination} Lat : ${lat2} Lon:$lon2""")

        val inRangeStations = find(lat1, lon1, lat2, lon2)

        var options = ArrayList<PathOption>()
        inRangeStations.first.parallelStream().forEach { source ->
            inRangeStations.second.parallelStream().forEach { destination ->
                var sourceVertex = graph.vertices.get(source)
                var destinationVertex = graph.vertices.get(destination)

                var path = graph.shortest_path(sourceVertex, destinationVertex)
                if (path != null && path.first.size > 0 && path.second.size > 0 && path.first.size < 100) {
                    var resultStations = Vertex.to(path.first, stations)

                    var duration = path.second.first()

                    val option = PathOption(
                        stations.find { o -> o.id == source }!!,
                        stations.find { o -> o.id == destination }!!,
                        resultStations,
                        duration.toInt()
                    )
                    if (option.duration > 0) {
                        options.add(option)
                    }
                }
            }
        }

        result = resultOperation(options, destination)


        return Observable.just(result)
    }

    private fun resultOperation(
        options: ArrayList<PathOption>,
        destination: String
    ): ArrayList<String> {
        var result = ArrayList<String>()
        if (options.size > 0) {
            var distinctOptions = options.distinctBy { o -> o.duration }
            var option1 = PathOption(Station(), Station(), ArrayList(), 0)
            var option2 = PathOption(Station(), Station(), ArrayList(), 0)
            var option3 = PathOption(Station(), Station(), ArrayList(), 0)
            if (options.size >= 1) {
                option1 = distinctOptions.minBy { o -> o.duration }!!
                distinctOptions =
                    distinctOptions.stream().filter { o -> o.duration != option1.duration }
                        .collect(Collectors.toList())
                option1.let { createOptionStr(it, 1, destination) }.let { result.add(it) }
            }
            if (options.size >= 2) {
                distinctOptions =
                    distinctOptions.stream().filter { o -> o.duration != option1.duration }
                        .collect(Collectors.toList())
                option2 = distinctOptions.minBy { o -> o.duration }!!
                result.add(createOptionStr(option2, 2, destination))
            }
            if (options.size >= 3) {
                distinctOptions =
                    distinctOptions.stream().filter { o -> o.duration != option2.duration }
                        .collect(Collectors.toList())
                option3 = distinctOptions.minBy { o -> o.duration }!!
                result.add(createOptionStr(option3, 3, destination))
            }
        }
        return result
    }


    fun createOptionStr(
        option: PathOption,
        num: Int,
        destination: String
    ): String {
        var text = ""

        text = text.plus(" Options --> ").plus(num).plus(" Walk To " + option.source.info)

        var duration = (TransportationType.WALK.value * 2) + option.duration
        var index = 0
        if (option.path.size < 50) {
            for (value in option.path) {
                text = if (value.type == TransportationType.BUS) {
                    text.plus("\n" + (index + 1) + ") Take the " + value.type.toString() + " station : " + value.station)
                } else {
                    text.plus("\n" + (index + 1) + ") Take the " + value.type.toString() + " station : " + value.station)

                }
                index++
            }

            text = text.plus("\n Get off " + option.path.last().type.toString() + " and walk to ")
                .plus(destination)
                .plus("\n Trip Will Takes : ")
                .plus(duration).plus(" Minutes")
        } else {
            text = "Options not found"
        }

        return text
    }


    fun searchLocation(
        location: String,
        transportationType: TransportationType?
    ): Pair<Double, Double> {
        var addressList: List<Address>? = null


        var locationUpper = location.toUpperCase()
        if (locationUpper == null || locationUpper == "") {
            println("provide location")
        } else {

            locationUpper = locationUpper
                .plus(getSearchTextAccordingToTransType(transportationType))
                .plus(" izmir turkiye ")

            val geoCoder = Geocoder(context)
            try {
                //izmir için
                println(" Searching Test : " + locationUpper)
                addressList = geoCoder.getFromLocationName(locationUpper, 1)

            } catch (e: IOException) {
                e.printStackTrace()
            }
            if (addressList == null) {
                println("GrapManager -> Adresslist returned null")
                return Pair(0.0, 0.0)
            }
            if (addressList !== null && addressList.size > 0) {
                val address = addressList[0]
                //println(address.latitude.toString() + " " + address.longitude)
                return Pair(address.latitude, address.longitude)
            }
        }
        return Pair(0.0, 0.0)
    }

    fun calculateDuration(path: List<Station>): Int {
        return path.stream().mapToInt { o -> o.type.value }.sum()
    }

    fun deg2rad(deg: Double): Double {
        return (deg * Math.PI / 180.0)
    }

    fun rad2deg(rad: Double): Double {
        return (rad * 180.0 / Math.PI)
    }

    fun getSearchTextAccordingToTransType(transportationType: TransportationType?): String {

        if (transportationType == null)
            return ""

        when (transportationType) {
            TransportationType.BUS -> {
                return " Otobüs durağı "
            }
            TransportationType.METRO -> {
                return " metro istasyonu "
            }
            TransportationType.TRAM -> {
                return " tramvay durağı  "
            }
            TransportationType.IZBAN -> {
                return " tren istasyonu "
            }
        }
        return ""
    }

    fun distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        var theta = lon1 - lon2
        var dist =
            Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(
                deg2rad(lat2)
            ) * Math.cos(deg2rad(theta))
        dist = Math.acos(dist)
        dist = rad2deg(dist)
        dist *= 60 * 1.1515
        return dist
    }


}

