package com.ozyilmaz.izway.core;

public final class MockDataMain {

    public static Vertex a1 = new Vertex(0, "Doğal Yaşam Parkı", TransportationType.BUS, "777");
    public static Vertex a2 = new Vertex(1, "Sasalı Anadolu Ögretmen Lisesi", TransportationType.BUS, "777");
    public static Vertex a3 = new Vertex(2, "Neşeli", TransportationType.BUS, "777");
    public static Vertex a4 = new Vertex(3, "Manolya", TransportationType.BUS, "777");
    public static Vertex a5 = new Vertex(4, "Çiçek", TransportationType.BUS, "777");
    public static Vertex a6 = new Vertex(5, "Sasalı Meydanı", TransportationType.BUS, "777");
    public static Vertex a7 = new Vertex(6, "Sasalı Giriş", TransportationType.BUS, "777");
    public static Vertex a8 = new Vertex(7, "Sasalı Doğal YaşamParkı", TransportationType.BUS, "777");
    public static Vertex a9 = new Vertex(8, "Çakabey", TransportationType.BUS, "777");
    public static Vertex a10 = new Vertex(9, "AnaJet Üssü", TransportationType.BUS, "777");
    public static Vertex a11 = new Vertex(10, "Sasalı PiknikAlanı", TransportationType.BUS, "777");
    public static Vertex a12 = new Vertex(11, "Kaklıç Kavşağı", TransportationType.BUS, "777");
    public static Vertex a13 = new Vertex(12, "Kutup Yıldızı", TransportationType.BUS, "777");
    public static Vertex a14 = new Vertex(13, "Atık Su", TransportationType.BUS, "777");
    public static Vertex a15 = new Vertex(14, "Bankalar", TransportationType.BUS, "777");
    public static Vertex a16 = new Vertex(15, "Eltaş", TransportationType.BUS, "777");
    public static Vertex a17 = new Vertex(16, "Organize Sanayi", TransportationType.BUS, "777");
    public static Vertex a18 = new Vertex(17, "Aktaş", TransportationType.BUS, "777");
    public static Vertex a19 = new Vertex(18, "Atakent Anadolu Lisesi", TransportationType.BUS, "777");
    public static Vertex a20 = new Vertex(19, "Beşikçioğlu Cami", TransportationType.BUS, "777");
    public static Vertex a21 = new Vertex(20, "Bostanlı Pazaryeri", TransportationType.BUS, "777");
    public static Vertex a22 = new Vertex(21, "Bostanlı Market", TransportationType.BUS, "777");
    public static Vertex a23 = new Vertex(22, "Bostanlı ", TransportationType.BUS, "777");
    public static Vertex a24 = new Vertex(23, "Osmanbey Parkı", TransportationType.BUS, "777");
    public static Vertex a25 = new Vertex(24, "Karşıyaka İskele", TransportationType.BUS, "777");


    /* 969 Numaralı Otobüs Hattı Durakları */
    public static Vertex b1 = new Vertex(25, "Balçova Son Durak", TransportationType.BUS, "969");
    public static Vertex b2 = new Vertex(26, "Teleferik", TransportationType.BUS, "969");
    public static Vertex b3 = new Vertex(27, "Ekonomi", TransportationType.BUS, "969");
    public static Vertex b4 = new Vertex(28, "Salih Dede Anadolu Lisesi", TransportationType.BUS, "969");
    public static Vertex b5 = new Vertex(29, "Çifte Selviler", TransportationType.BUS, "969");
    public static Vertex b6 = new Vertex(30, "Gümüş", TransportationType.BUS, "969");
    public static Vertex b7 = new Vertex(31, "Merkez Cami", TransportationType.BUS, "969");
    public static Vertex b8 = new Vertex(32, "Asmaaltı", TransportationType.BUS, "969");
    public static Vertex b9 = new Vertex(33, "Tatbikat Cami", TransportationType.BUS, "969");
    public static Vertex b10 = new Vertex(34, "Duygu", TransportationType.BUS, "969");
    public static Vertex b11 = new Vertex(35, "Kabristan", TransportationType.BUS, "969");
    public static Vertex b12 = new Vertex(36, "Balçova Lisesi", TransportationType.BUS, "969");
    public static Vertex b13 = new Vertex(37, "Barış", TransportationType.BUS, "969");
    public static Vertex b14 = new Vertex(38, "Fahrettin Altay ", TransportationType.BUS, "969");

    /* 551 Numaralı Otobüs Hattı Durakları*/
    public static Vertex c1 = new Vertex(39, "Narlıdere", TransportationType.BUS, "551");
    public static Vertex c2 = new Vertex(40, "Subay Gazinosu", TransportationType.BUS, "551");
    public static Vertex c3 = new Vertex(41, "Lojmanlar", TransportationType.BUS, "551");
    public static Vertex c4 = new Vertex(42, "Pertev Bey", TransportationType.BUS, "551");
    public static Vertex c5 = new Vertex(43, "İstihkam Okulu", TransportationType.BUS, "551");
    public static Vertex c6 = new Vertex(44, "Narlıdere Kaymakamlık", TransportationType.BUS, "551");
    public static Vertex c7 = new Vertex(45, "Narlıdere Belediye", TransportationType.BUS, "551");
    public static Vertex c8 = new Vertex(46, "Şehitlik", TransportationType.BUS, "551");
    public static Vertex c9 = new Vertex(47, "Siteler", TransportationType.BUS, "551");
    public static Vertex c10 = new Vertex(48, "Köprübaşı", TransportationType.BUS, "551");
    public static Vertex c11 = new Vertex(49, "Uludağ", TransportationType.BUS, "551");
    public static Vertex c12 = new Vertex(50, "Narlıdere Cami", TransportationType.BUS, "551");
    public static Vertex c13 = new Vertex(51, "Narlıdere İtfaiye", TransportationType.BUS, "551");
    public static Vertex c14 = new Vertex(52, "Balcı", TransportationType.BUS, "551");
    public static Vertex c15 = new Vertex(53, "Güzel Sanatlar Fakültesi", TransportationType.BUS, "551");
    public static Vertex c16 = new Vertex(54, "İzsu", TransportationType.BUS, "551");
    public static Vertex c17 = new Vertex(55, "Kantar", TransportationType.BUS, "551");
    public static Vertex c18 = new Vertex(56, "Dokuz Eylül", TransportationType.BUS, "551");
    public static Vertex c19 = new Vertex(57, "Dörtyol", TransportationType.BUS, "551");
    public static Vertex c20 = new Vertex(58, "Hoca", TransportationType.BUS, "551");
    public static Vertex c21 = new Vertex(59, "Teleferik", TransportationType.BUS, "551");
    public static Vertex c22 = new Vertex(60, "İşbankası Evleri", TransportationType.BUS, "551");
    public static Vertex c23 = new Vertex(61, "Molla Kuyusu", TransportationType.BUS, "551");
    public static Vertex c24 = new Vertex(62, "Balçova Kahveler", TransportationType.BUS, "551");
    public static Vertex c25 = new Vertex(63, "Beyaz", TransportationType.BUS, "551");
    public static Vertex c26 = new Vertex(64, "Fahrettin Altay ", TransportationType.BUS, "551");
    public static Vertex c27 = new Vertex(65, "Mehmetçik", TransportationType.BUS, "551");
    public static Vertex c28 = new Vertex(66, "Ordu Pazarı", TransportationType.BUS, "551");
    public static Vertex c29 = new Vertex(67, "2.Oyak Sitesi", TransportationType.BUS, "551");
    public static Vertex c30 = new Vertex(68, "Fahrettin Altay Son Durak", TransportationType.BUS, "551");


    //681 Numaralı Otobüs Hattı Durakları
    public static Vertex d1 = new Vertex(69, "Fahrettin Altay Son Durak", TransportationType.BUS, "681");
    public static Vertex d2 = new Vertex(70, "2.Oyak Sitesi", TransportationType.BUS, "681");
    public static Vertex d3 = new Vertex(71, "Ordu Pazarı", TransportationType.BUS, "681");
    public static Vertex d4 = new Vertex(72, "Mehmetçik", TransportationType.BUS, "681");
    public static Vertex d5 = new Vertex(73, "Fahrettin Altay ", TransportationType.BUS, "681");
    public static Vertex d6 = new Vertex(74, "Göztepe Stadı", TransportationType.BUS, "681");
    public static Vertex d7 = new Vertex(75, "Denizmen", TransportationType.BUS, "681");
    public static Vertex d8 = new Vertex(76, "Hıfzı Sıhha", TransportationType.BUS, "681");
    public static Vertex d9 = new Vertex(77, "Amerikan Koleji", TransportationType.BUS, "681");
    public static Vertex d10 = new Vertex(78, "Susuz Dede", TransportationType.BUS, "681");
    public static Vertex d11 = new Vertex(79, "Hakim Evleri", TransportationType.BUS, "681");
    public static Vertex d12 = new Vertex(80, "Nokta", TransportationType.BUS, "681");
    public static Vertex d13 = new Vertex(81, "Çeşme", TransportationType.BUS, "681");
    public static Vertex d14 = new Vertex(82, "Şoförler Lokalı", TransportationType.BUS, "681");
    public static Vertex d15 = new Vertex(83, "İzmirspor", TransportationType.BUS, "681");
    public static Vertex d16 = new Vertex(84, "Altıntaş", TransportationType.BUS, "681");
    public static Vertex d17 = new Vertex(85, "Bayramyeri", TransportationType.BUS, "681");
    public static Vertex d18 = new Vertex(86, "Koruluk", TransportationType.BUS, "681");
    public static Vertex d19 = new Vertex(87, "Kestelli", TransportationType.BUS, "681");
    public static Vertex d20 = new Vertex(88, "Mezarlıkbaşı", TransportationType.BUS, "681");
    public static Vertex d21 = new Vertex(89, "Montrö", TransportationType.BUS, "681");

    /* 963 Numaralı Otobüs Hattı Durakları*/
    public static Vertex e1 = new Vertex(90, "Evka 3 ", TransportationType.BUS, "963");
    public static Vertex e2 = new Vertex(91, "Ege Üniversitesi Lojmanları", TransportationType.BUS, "963");
    public static Vertex e3 = new Vertex(92, "Suphi Koyuncuoğlu", TransportationType.BUS, "963");
    public static Vertex e4 = new Vertex(93, "Ata", TransportationType.BUS, "963");
    public static Vertex e5 = new Vertex(94, "Hükümet Konağı", TransportationType.BUS, "963");
    public static Vertex e6 = new Vertex(95, "Bornova İzsu", TransportationType.BUS, "963");
    public static Vertex e7 = new Vertex(96, "Çınar", TransportationType.BUS, "963");
    public static Vertex e8 = new Vertex(97, "Bornova Stadı", TransportationType.BUS, "963");
    public static Vertex e9 = new Vertex(98, "Çağdaş", TransportationType.BUS, "963");
    public static Vertex e10 = new Vertex(99, "Mustafa Kemal Lisesi", TransportationType.BUS, "963");
    public static Vertex e11 = new Vertex(100, "Çamkıran", TransportationType.BUS, "963");
    public static Vertex e12 = new Vertex(101, "Şehit Murat Aslantürk", TransportationType.BUS, "963");
    public static Vertex e13 = new Vertex(102, "Şehit Hakan Ünal", TransportationType.BUS, "963");
    public static Vertex e14 = new Vertex(103, "Adalet Mahallesi", TransportationType.BUS, "963");
    public static Vertex e15 = new Vertex(104, "Halide Edip Adıvar", TransportationType.BUS, "963");
    public static Vertex e16 = new Vertex(105, "Adliye", TransportationType.BUS, "963");
    public static Vertex e17 = new Vertex(106, "Yeni Kent", TransportationType.BUS, "963");
    public static Vertex e18 = new Vertex(107, "Liman", TransportationType.BUS, "963");
    public static Vertex e19 = new Vertex(108, "Alsancak Garı", TransportationType.BUS, "963");

    /* 302 Numaralı Otobüs Hattı Durakları*/
    public static Vertex f1 = new Vertex(109, "Otogar Yeni", TransportationType.BUS, "302");
    public static Vertex f2 = new Vertex(110, "Otogar", TransportationType.BUS, "302");
    public static Vertex f3 = new Vertex(111, "Otogar Benzinlik", TransportationType.BUS, "302");
    public static Vertex f4 = new Vertex(112, "Mimar Sinan ML", TransportationType.BUS, "302");
    public static Vertex f5 = new Vertex(113, "Şehitler İÖO", TransportationType.BUS, "302");
    public static Vertex f6 = new Vertex(114, "Altındağ Belediye", TransportationType.BUS, "302");
    public static Vertex f7 = new Vertex(115, "Havuzlu Kahve", TransportationType.BUS, "302");
    public static Vertex f8 = new Vertex(116, "Şehitler", TransportationType.BUS, "302");
    public static Vertex f9 = new Vertex(117, "Kokluca Mezarlığı", TransportationType.BUS, "302");
    public static Vertex f10 = new Vertex(10, "Evrenosoğlu iöo", TransportationType.BUS, "302");
    public static Vertex f11 = new Vertex(118, "Meriç Mahallesi Çeşme", TransportationType.BUS, "302");
    public static Vertex f12 = new Vertex(119, "MTK 1.Giriş", TransportationType.BUS, "302");
    public static Vertex f13 = new Vertex(120, "Halkapınar İzsu", TransportationType.BUS, "302");
    public static Vertex f14 = new Vertex(121, "Yenişehir Ptt", TransportationType.BUS, "302");
    public static Vertex f15 = new Vertex(122, "Doğum Hastanesi", TransportationType.BUS, "302");
    public static Vertex f16 = new Vertex(123, "Ziya Gökalp İÖO", TransportationType.BUS, "302");
    public static Vertex f17 = new Vertex(124, "Eşrefpaşa Hastane", TransportationType.BUS, "302");
    public static Vertex f18 = new Vertex(125, "Kemer", TransportationType.BUS, "302");
    public static Vertex f19 = new Vertex(126, "Basmane Gar", TransportationType.BUS, "302");
    public static Vertex f20 = new Vertex(127, "Çardak", TransportationType.BUS, "302");
    public static Vertex f21 = new Vertex(128, "İskele", TransportationType.BUS, "302");
    public static Vertex f22 = new Vertex(129, "Konak ", TransportationType.BUS, "302");

    /* 304 Numaralı Otobüs Hattı Durakları*/
    public static Vertex g1 = new Vertex(130, "Tınaztepe", TransportationType.BUS, "304");
    public static Vertex g2 = new Vertex(131, "Begos", TransportationType.BUS, "304");
    public static Vertex g3 = new Vertex(132, "Papatya", TransportationType.BUS, "304");
    public static Vertex g4 = new Vertex(133, "Eski Mezarlık", TransportationType.BUS, "304");
    public static Vertex g5 = new Vertex(134, "Hasanağa Bahçesi", TransportationType.BUS, "304");
    public static Vertex g6 = new Vertex(135, "Buca üçkuyular Meydan", TransportationType.BUS, "304");
    public static Vertex g7 = new Vertex(136, "Sağlık Ocağı", TransportationType.BUS, "304");
    public static Vertex g8 = new Vertex(137, "Buca Devlet Hastanesi", TransportationType.BUS, "304");
    public static Vertex g9 = new Vertex(138, "Dokuz Eylül Eğitim Fakültesi", TransportationType.BUS, "304");
    public static Vertex g10 = new Vertex(139, "Buca SGK", TransportationType.BUS, "304");
    public static Vertex g11 = new Vertex(140, "Öğretmen Evleri", TransportationType.BUS, "304");
    public static Vertex g12 = new Vertex(141, "Buca Belediye Sarayı", TransportationType.BUS, "304");
    public static Vertex g13 = new Vertex(142, "Ceza Evi", TransportationType.BUS, "304");
    public static Vertex g14 = new Vertex(143, "Yeni Mahalle", TransportationType.BUS, "304");
    public static Vertex g15 = new Vertex(144, "Şirinyer PTT", TransportationType.BUS, "304");
    public static Vertex g16 = new Vertex(145, "Şirinyer Bankalar", TransportationType.BUS, "304");
    public static Vertex g17 = new Vertex(146, "Fabrika", TransportationType.BUS, "304");
    public static Vertex g18 = new Vertex(147, "Yeniyol", TransportationType.BUS, "304");
    public static Vertex g19 = new Vertex(148, "Konak ", TransportationType.BUS, "304");

    /* 470 Numaralı Otobüs Hattı Durakları*/
    public static Vertex h1 = new Vertex(149, "Tınaztepe", TransportationType.BUS, "470");
    public static Vertex h2 = new Vertex(150, "Begos", TransportationType.BUS, "470");
    public static Vertex h3 = new Vertex(151, "Papatya", TransportationType.BUS, "470");
    public static Vertex h4 = new Vertex(152, "Eski Mezarlık", TransportationType.BUS, "470");
    public static Vertex h5 = new Vertex(153, "İktsadi Bilimler Fakültesi", TransportationType.BUS, "470");
    public static Vertex h6 = new Vertex(154, "Buca üçkuyular Meydan", TransportationType.BUS, "470");
    public static Vertex h7 = new Vertex(155, "Sağlık Ocağı", TransportationType.BUS, "470");
    public static Vertex h8 = new Vertex(156, "Buca Devlet Hastanesi", TransportationType.BUS, "470");
    public static Vertex h9 = new Vertex(157, "Dokuz Eylül Eğitim Fakültesi", TransportationType.BUS, "470");
    public static Vertex h10 = new Vertex(158, "Buca SGK", TransportationType.BUS, "470");
    public static Vertex h11 = new Vertex(159, "Öğretmen Evleri", TransportationType.BUS, "470");
    public static Vertex h12 = new Vertex(160, "Buca Belediye Sarayı", TransportationType.BUS, "470");
    public static Vertex h13 = new Vertex(161, "Ceza Evi", TransportationType.BUS, "470");
    public static Vertex h14 = new Vertex(162, "Yeni Mahalle", TransportationType.BUS, "470");
    public static Vertex h15 = new Vertex(163, "Şirinyer PTT", TransportationType.BUS, "470");
    public static Vertex h16 = new Vertex(164, "Şirinyer Karakol", TransportationType.BUS, "470");
    public static Vertex h17 = new Vertex(165, "Nato", TransportationType.BUS, "470");
    public static Vertex h18 = new Vertex(166, "Şelale Parkı", TransportationType.BUS, "470");
    public static Vertex h19 = new Vertex(167, "Konak Anadolu Lisesi", TransportationType.BUS, "470");
    public static Vertex h20 = new Vertex(168, "Yağhaneler 2", TransportationType.BUS, "470");
    public static Vertex h21 = new Vertex(169, "Yağhaneler", TransportationType.BUS, "470");
    public static Vertex h22 = new Vertex(170, "Eşrefpaşa", TransportationType.BUS, "470");
    public static Vertex h23 = new Vertex(171, "Koruluk", TransportationType.BUS, "470");
    public static Vertex h24 = new Vertex(172, "Kestelli", TransportationType.BUS, "470");
    public static Vertex h25 = new Vertex(173, "Mezarlıkbaşı", TransportationType.BUS, "470");
    public static Vertex h26 = new Vertex(174, "Montrö", TransportationType.BUS, "470");

    /* 921 Numaralı Otobüs Hattı Durakları*/
    public static Vertex i1 = new Vertex(175, "Bostanlı ", TransportationType.BUS, "921");
    public static Vertex i2 = new Vertex(176, "Osmanbey Parkı", TransportationType.BUS, "921");
    public static Vertex i3 = new Vertex(177, "Karşıyaka İskele", TransportationType.BUS, "921");
    public static Vertex i4 = new Vertex(178, "Muammer Aksoy Parkı", TransportationType.BUS, "921");
    public static Vertex i5 = new Vertex(179, "Selçuk Yaşar İÖO", TransportationType.BUS, "921");
    public static Vertex i6 = new Vertex(180, "Tersane", TransportationType.BUS, "921");
    public static Vertex i7 = new Vertex(181, "Turan", TransportationType.BUS, "921");
    public static Vertex i8 = new Vertex(182, "Bayraklı Üst Geçit", TransportationType.BUS, "921");
    public static Vertex i9 = new Vertex(183, "Liman", TransportationType.BUS, "921");
    public static Vertex i10 = new Vertex(184, "Alsancak Garı", TransportationType.BUS, "921");

    /* 912 Numaralı Otobüs Hattı Durakları*/
    public static Vertex j1 = new Vertex(185, "Atakent ", TransportationType.BUS, "912");
    public static Vertex j2 = new Vertex(186, "Tüvturk", TransportationType.BUS, "912");
    public static Vertex j3 = new Vertex(187, "Balatçık Kahveler", TransportationType.BUS, "912");
    public static Vertex j4 = new Vertex(188, "Ata", TransportationType.BUS, "912");
    public static Vertex j5 = new Vertex(189, "Küçük Çiğli", TransportationType.BUS, "912");
    public static Vertex j6 = new Vertex(190, "Santral", TransportationType.BUS, "912");
    public static Vertex j7 = new Vertex(191, "Şaraphane", TransportationType.BUS, "912");
    public static Vertex j8 = new Vertex(192, "Çiğli Belediye", TransportationType.BUS, "912");
    public static Vertex j9 = new Vertex(193, "Eğitim Gönüllüleri", TransportationType.BUS, "912");
    public static Vertex j10 = new Vertex(194, "Çiğli itfaiye", TransportationType.BUS, "912");
    public static Vertex j11 = new Vertex(195, "Karşıyaka Anadolu Lisesi", TransportationType.BUS, "912");
    public static Vertex j12 = new Vertex(196, "Ayyıldız", TransportationType.BUS, "912");
    public static Vertex j13 = new Vertex(197, "Karşıyaka Jandarma", TransportationType.BUS, "912");
    public static Vertex j14 = new Vertex(198, "Kayalar Mezarlığı", TransportationType.BUS, "912");
    public static Vertex j15 = new Vertex(199, "Serinkuyu", TransportationType.BUS, "912");
    public static Vertex j16 = new Vertex(200, "Dedebaşı", TransportationType.BUS, "912");
    public static Vertex j17 = new Vertex(201, "Soğukkuyu Trafik", TransportationType.BUS, "912");
    public static Vertex j18 = new Vertex(202, "Öztürk", TransportationType.BUS, "912");
    public static Vertex j19 = new Vertex(203, "Naldöken", TransportationType.BUS, "912");
    public static Vertex j20 = new Vertex(204, "Turan", TransportationType.BUS, "912");
    public static Vertex j21 = new Vertex(205, "Bayraklı üst Geçit", TransportationType.BUS, "912");
    public static Vertex j22 = new Vertex(206, "Liman", TransportationType.BUS, "912");
    public static Vertex j23 = new Vertex(207, "Alsancak Garı", TransportationType.BUS, "912");

    /* 543 Numaralı Otobüs Hattı Durakları*/
    public static Vertex k1 = new Vertex(208, "Bostanlı ", TransportationType.BUS, "543");
    public static Vertex k2 = new Vertex(209, "Osmanbey Parkı", TransportationType.BUS, "543");
    public static Vertex k3 = new Vertex(210, "Karşıyaka İskele", TransportationType.BUS, "543");
    public static Vertex k4 = new Vertex(211, "Muammer Aksoy Parkı", TransportationType.BUS, "543");
    public static Vertex k5 = new Vertex(212, "Selçuk Yaşar İÖO", TransportationType.BUS, "543");
    public static Vertex k6 = new Vertex(213, "Tersane", TransportationType.BUS, "543");
    public static Vertex k7 = new Vertex(214, "Turan", TransportationType.BUS, "543");
    public static Vertex k8 = new Vertex(215, "Bayraklı Üst Geçit", TransportationType.BUS, "543");
    public static Vertex k9 = new Vertex(216, "Piyale", TransportationType.BUS, "543");
    public static Vertex k10 = new Vertex(217, "Smyrna", TransportationType.BUS, "543");
    public static Vertex k11 = new Vertex(218, "Manas", TransportationType.BUS, "543");
    public static Vertex k12 = new Vertex(219, "Bayraklı Depo", TransportationType.BUS, "543");
    public static Vertex k13 = new Vertex(220, "Halide E.Adıvar", TransportationType.BUS, "543");
    public static Vertex k14 = new Vertex(221, "Adliye", TransportationType.BUS, "543");
    public static Vertex k15 = new Vertex(222, "Üçüncü Sanayi", TransportationType.BUS, "543");
    public static Vertex k16 = new Vertex(223, "Tarım Kredi Koop.", TransportationType.BUS, "543");
    public static Vertex k17 = new Vertex(224, "Stadyum İstasyon", TransportationType.BUS, "543");
    public static Vertex k18 = new Vertex(225, "Mersinli", TransportationType.BUS, "543");
    public static Vertex k19 = new Vertex(226, "Çamdibi Sağ.Ocağı", TransportationType.BUS, "543");
    public static Vertex k20 = new Vertex(227, "Atatürk Stadı", TransportationType.BUS, "543");
    public static Vertex k21 = new Vertex(228, "Halkapınar Tramvay", TransportationType.BUS, "543");
    public static Vertex k22 = new Vertex(229, "Halkapınar ", TransportationType.BUS, "543");


    /* 680 Numaralı Otobüs Hattı Durakları*/
    public static Vertex n1 = new Vertex(230, "Yeşilyurt", TransportationType.BUS, "680");
    public static Vertex n2 = new Vertex(231, "Yadigar Sitesi", TransportationType.BUS, "680");
    public static Vertex n3 = new Vertex(232, "Yadigar Cami", TransportationType.BUS, "680");
    public static Vertex n4 = new Vertex(233, "Egzoscu", TransportationType.BUS, "680");
    public static Vertex n5 = new Vertex(234, "Ülkü", TransportationType.BUS, "680");
    public static Vertex n6 = new Vertex(235, "Seniye Hasan İÖO", TransportationType.BUS, "680");
    public static Vertex n7 = new Vertex(236, "Yıkık Cami 2", TransportationType.BUS, "680");
    public static Vertex n8 = new Vertex(237, "Kuyu", TransportationType.BUS, "680");
    public static Vertex n9 = new Vertex(238, "Bayram Kahya", TransportationType.BUS, "680");
    public static Vertex n10 = new Vertex(239, "Kara Selvi", TransportationType.BUS, "680");
    public static Vertex n11 = new Vertex(240, "Bozkaya Cami", TransportationType.BUS, "680");
    public static Vertex n12 = new Vertex(241, "Kestelli", TransportationType.BUS, "680");
    public static Vertex n13 = new Vertex(242, "Zincirlikuyu", TransportationType.BUS, "680");
    public static Vertex n14 = new Vertex(243, "Narlık", TransportationType.BUS, "680");
    public static Vertex n15 = new Vertex(244, "Kilimcitepe", TransportationType.BUS, "680");
    public static Vertex n16 = new Vertex(245, "Yağhaneler 3", TransportationType.BUS, "680");
    public static Vertex n17 = new Vertex(246, "Yağhaneler", TransportationType.BUS, "680");
    public static Vertex n18 = new Vertex(247, "Eşrefpaşa", TransportationType.BUS, "680");
    public static Vertex n19 = new Vertex(248, "Koruluk", TransportationType.BUS, "680");
    public static Vertex n20 = new Vertex(249, "Kestelli", TransportationType.BUS, "680");
    public static Vertex n21 = new Vertex(250, "Mezarlıkbaşı", TransportationType.BUS, "680");
    public static Vertex n22 = new Vertex(251, "Montrö", TransportationType.BUS, "680");

    /* 691 Numaralı Otobüs Hattı Durakları*/

    public static Vertex m1 = new Vertex(251, "Sosyal Konutlar", TransportationType.BUS, "691");
    public static Vertex m2 = new Vertex(252, "Özcan Sitesi", TransportationType.BUS, "691");
    public static Vertex m3 = new Vertex(253, "Gaziemir İMKB", TransportationType.BUS, "691");
    public static Vertex m4 = new Vertex(254, "Şehit Polis Ahmet Atilla İÖO", TransportationType.BUS, "691");
    public static Vertex m5 = new Vertex(255, "Şehit Üsteğmen Hakan Özkaner", TransportationType.BUS, "691");
    public static Vertex m6 = new Vertex(256, "Birinci Nizamiye", TransportationType.BUS, "691");
    public static Vertex m7 = new Vertex(257, "İkinci Nizamiye", TransportationType.BUS, "691");
    public static Vertex m8 = new Vertex(258, "Halit Tan Parkı", TransportationType.BUS, "691");
    public static Vertex m9 = new Vertex(259, "Yeşil Mah. Muhtarlık", TransportationType.BUS, "691");
    public static Vertex m10 = new Vertex(260, "Gaziemir Trafo", TransportationType.BUS, "691");
    public static Vertex m11 = new Vertex(261, "Gaziemir Trafo", TransportationType.BUS, "691");
    public static Vertex m12 = new Vertex(262, "Gaziemir Merkez Cami", TransportationType.BUS, "691");
    public static Vertex m13 = new Vertex(263, "Gaziemir Belediye", TransportationType.BUS, "691");
    public static Vertex m14 = new Vertex(264, "Gaziemir Ptt", TransportationType.BUS, "691");
    public static Vertex m15 = new Vertex(265, "Büyükşehir Kurs Merkezi", TransportationType.BUS, "691");
    public static Vertex m16 = new Vertex(266, "Ulaştırma", TransportationType.BUS, "691");
    public static Vertex m17 = new Vertex(267, "Leylak", TransportationType.BUS, "691");
    public static Vertex m18 = new Vertex(268, "Ege Serbest Bölge 2", TransportationType.BUS, "691");
    public static Vertex m19 = new Vertex(269, "Aktepe", TransportationType.BUS, "691");
    public static Vertex m20 = new Vertex(270, "Gaziemir Semt Garajı", TransportationType.BUS, "691");
    public static Vertex m21 = new Vertex(271, "Sinem", TransportationType.BUS, "691");
    public static Vertex m22 = new Vertex(272, "Karabağlar", TransportationType.BUS, "691");
    public static Vertex m23 = new Vertex(273, "Paşa Köprüsü", TransportationType.BUS, "691");
    public static Vertex m24 = new Vertex(274, "Kızılcık", TransportationType.BUS, "691");
    public static Vertex m25 = new Vertex(275, "Söğüt", TransportationType.BUS, "691");
    public static Vertex m26 = new Vertex(276, "Cumhuriyet Lisesi", TransportationType.BUS, "691");
    public static Vertex m27 = new Vertex(277, "Kaymakkuyu", TransportationType.BUS, "691");
    public static Vertex m28 = new Vertex(278, "Çitlembik", TransportationType.BUS, "691");
    public static Vertex m29 = new Vertex(279, "Orcaner", TransportationType.BUS, "691");
    public static Vertex m30 = new Vertex(280, "Hasan Hüseyinler", TransportationType.BUS, "691");
    public static Vertex m31 = new Vertex(281, "Elka", TransportationType.BUS, "691");
    public static Vertex m32 = new Vertex(282, "Yağhaneler 3", TransportationType.BUS, "691");
    public static Vertex m33 = new Vertex(283, "Yağhaneler", TransportationType.BUS, "691");
    public static Vertex m34 = new Vertex(284, "Eşrefpaşa", TransportationType.BUS, "691");
    public static Vertex m35 = new Vertex(285, "Koruluk", TransportationType.BUS, "691");
    public static Vertex m36 = new Vertex(286, "Kestelli", TransportationType.BUS, "691");
    public static Vertex m37 = new Vertex(287, "Mezarlıkbaşı", TransportationType.BUS, "691");
    public static Vertex m38 = new Vertex(288, "Montrö", TransportationType.BUS, "691");

    /* Karşıyaka Tramvay Hattı Durakları*/
    public static Vertex x1 = new Vertex(289, "Mavişehir", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x2 = new Vertex(290, "Çevre Yolu", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x3 = new Vertex(291, "Mavişehir", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x4 = new Vertex(292, "Mustafa Kemal Spor Salonu", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x5 = new Vertex(293, "Bilim Müzesi", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x6 = new Vertex(294, "Atakent", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x7 = new Vertex(295, "Selçuk Yaşar", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x8 = new Vertex(296, "Vilayet Evleri", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x9 = new Vertex(297, "Çarşı", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x10 = new Vertex(298, "Bostanlı ", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x11 = new Vertex(299, "Yunuslar", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x12 = new Vertex(300, "Nikah Sarayı", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x13 = new Vertex(301, "Karşıyaka İskele", TransportationType.TRAM, "Karşıyaka Tramvayı");
    public static Vertex x14 = new Vertex(302, "Alaybey", TransportationType.TRAM, "Karşıyaka Tramvayı");

    /* Konak Tramvay Hattı Durakları */
    public static Vertex y1 = new Vertex(303, "Halkapınar ", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y2 = new Vertex(304, "Alsancak Garı", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y3 = new Vertex(305, "Atatürk Spor Salonu", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y4 = new Vertex(306, "Hocazede Cami", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y5 = new Vertex(307, "Kültürpark Atatürk Lisesi", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y6 = new Vertex(308, "Gazi Bulvarı", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y7 = new Vertex(309, "Konak ", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y8 = new Vertex(310, "Karataş", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y9 = new Vertex(311, "Karantina", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y10 = new Vertex(312, "Köprü", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y11 = new Vertex(313, "Sadıkbey", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y12 = new Vertex(314, "Göztepe", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y13 = new Vertex(315, "Güzelyalı", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y14 = new Vertex(316, "Adnan Saygun Sanat Merkezi", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y15 = new Vertex(317, "Üçkuyular Meydanı", TransportationType.TRAM, "Konak Tramvayı");
    public static Vertex y16 = new Vertex(318, "Fahrettin Altay", TransportationType.TRAM, "Konak Tramvayı");

    /* Metro Durakları */
    public static Vertex w1 = new Vertex(319, "Evka 3", TransportationType.METRO, "Metro");
    public static Vertex w2 = new Vertex(320, "Ege Üniversitesi", TransportationType.METRO, "Metro");
    public static Vertex w3 = new Vertex(321, "Bornova Hastane", TransportationType.METRO, "Metro");
    public static Vertex w4 = new Vertex(322, "Bölge", TransportationType.METRO, "Metro");
    public static Vertex w5 = new Vertex(323, "Sanayi", TransportationType.METRO, "Metro");
    public static Vertex w6 = new Vertex(324, "Stadyum", TransportationType.METRO, "Metro");
    public static Vertex w7 = new Vertex(325, "Halkapınar", TransportationType.METRO, "Metro");
    public static Vertex w8 = new Vertex(326, "Hilal", TransportationType.METRO, "Metro");
    public static Vertex w9 = new Vertex(327, "Basmane Gar", TransportationType.METRO, "Metro");
    public static Vertex w10 = new Vertex(328, "Çankaya", TransportationType.METRO, "Metro");
    public static Vertex w11 = new Vertex(329, "Konak", TransportationType.METRO, "Metro");
    public static Vertex w12 = new Vertex(330, "Üçyol", TransportationType.METRO, "Metro");
    public static Vertex w13 = new Vertex(331, "İzmirspor", TransportationType.METRO, "Metro");
    public static Vertex w14 = new Vertex(332, "Hatay", TransportationType.METRO, "Metro");
    public static Vertex w15 = new Vertex(333, "Göztepe", TransportationType.METRO, "Metro");
    public static Vertex w16 = new Vertex(334, "Poligon", TransportationType.METRO, "Metro");
    public static Vertex w17 = new Vertex(335, "Fahrettin Altay", TransportationType.METRO, "Metro");

    /* İzban Durakları */
    public static Vertex p1 = new Vertex(336, "Selçuk", TransportationType.IZBAN, "IZBAN");
    public static Vertex p2 = new Vertex(337, "Belevi", TransportationType.IZBAN, "IZBAN");
    public static Vertex p3 = new Vertex(338, "Sağlık", TransportationType.IZBAN, "IZBAN");
    public static Vertex p4 = new Vertex(339, "Tepeköy", TransportationType.IZBAN, "IZBAN");
    public static Vertex p5 = new Vertex(340, "Torbalı", TransportationType.IZBAN, "IZBAN");
    public static Vertex p6 = new Vertex(341, "Kuşçuburun", TransportationType.IZBAN, "IZBAN");
    public static Vertex p7 = new Vertex(342, "Pancar", TransportationType.IZBAN, "IZBAN");
    public static Vertex p8 = new Vertex(343, "Tekeli", TransportationType.IZBAN, "IZBAN");
    public static Vertex p9 = new Vertex(344, "Develi", TransportationType.IZBAN, "IZBAN");
    public static Vertex p10 = new Vertex(345, "Cumaovası", TransportationType.IZBAN, "IZBAN");
    public static Vertex p11 = new Vertex(346, "Adnan Menderes Havalimanı", TransportationType.IZBAN, "IZBAN");
    public static Vertex p12 = new Vertex(347, "Sarnıç", TransportationType.IZBAN, "IZBAN");
    public static Vertex p13 = new Vertex(348, "Gaziemir", TransportationType.IZBAN, "IZBAN");
    public static Vertex p14 = new Vertex(349, "Erbaş", TransportationType.IZBAN, "IZBAN");
    public static Vertex p15 = new Vertex(350, "Semt Garajı", TransportationType.IZBAN, "IZBAN");
    public static Vertex p16 = new Vertex(351, "İnkılap", TransportationType.IZBAN, "IZBAN");
    public static Vertex p17 = new Vertex(352, "Koşu", TransportationType.IZBAN, "IZBAN");
    public static Vertex p18 = new Vertex(353, "Şirinyer", TransportationType.IZBAN, "IZBAN");
    public static Vertex p19 = new Vertex(354, "Kemer", TransportationType.IZBAN, "IZBAN");
    public static Vertex p20 = new Vertex(355, "Hilal", TransportationType.IZBAN, "IZBAN");
    public static Vertex p21 = new Vertex(356, "Alsancak Garı", TransportationType.IZBAN, "IZBAN");
    public static Vertex p22 = new Vertex(357, "Halkapınar ", TransportationType.IZBAN, "IZBAN");
    public static Vertex p23 = new Vertex(358, "Salhane", TransportationType.IZBAN, "IZBAN");
    public static Vertex p24 = new Vertex(359, "Bayraklı", TransportationType.IZBAN, "IZBAN");
    public static Vertex p25 = new Vertex(360, "Turan", TransportationType.IZBAN, "IZBAN");
    public static Vertex p26 = new Vertex(361, "Naldöken", TransportationType.IZBAN, "IZBAN");
    public static Vertex p27 = new Vertex(362, "Alaybey", TransportationType.IZBAN, "IZBAN");
    public static Vertex p28 = new Vertex(363, "Karşıyaka", TransportationType.IZBAN, "IZBAN");
    public static Vertex p29 = new Vertex(364, "Nergiz", TransportationType.IZBAN, "IZBAN");
    public static Vertex p30 = new Vertex(365, "Demirköprü", TransportationType.IZBAN, "IZBAN");
    public static Vertex p31 = new Vertex(366, "Şemikler", TransportationType.IZBAN, "IZBAN");
    public static Vertex p32 = new Vertex(367, "Mavişehir", TransportationType.IZBAN, "IZBAN");
    public static Vertex p33 = new Vertex(368, "Çiğli", TransportationType.IZBAN, "IZBAN");
    public static Vertex p34 = new Vertex(369, "Ata Sanayi", TransportationType.IZBAN, "IZBAN");
    public static Vertex p35 = new Vertex(370, "Egekent", TransportationType.IZBAN, "IZBAN");
    public static Vertex p36 = new Vertex(371, "Ulukent", TransportationType.IZBAN, "IZBAN");
    public static Vertex p37 = new Vertex(372, "Egekent2t", TransportationType.IZBAN, "IZBAN");
    public static Vertex p38 = new Vertex(373, "Menemen", TransportationType.IZBAN, "IZBAN");
    public static Vertex p39 = new Vertex(374, "Hatundere", TransportationType.IZBAN, "IZBAN");
    public static Vertex p40 = new Vertex(375, "Biçerova", TransportationType.IZBAN, "IZBAN");
    public static Vertex p41 = new Vertex(376, "Aliağa", TransportationType.IZBAN, "IZBAN");

    /* Vapur İskeleleri*/
    public static Vertex v1 = new Vertex(377, "Üçkuyular Vapur İskelesi", TransportationType.STREAMBOAT_LINE_UCKUYULAR, "VAPUR");
    public static Vertex v2 = new Vertex(378, "Güzelyalı Vapur İskelesi", TransportationType.STREAMBOAT_LINE_GUZELYALI, "VAPUR");
    public static Vertex v3 = new Vertex(379, "Konak Vapur İskelesi", TransportationType.STREAMBOAT_LINE_KONAK, "VAPUR");
    public static Vertex v4 = new Vertex(380, "Pasaport Vapur İskelesi", TransportationType.STREAMBOAT_LINE_PASAPORT, "VAPUR");
    public static Vertex v5 = new Vertex(381, "Alsancak Vapur İskelesi", TransportationType.STREAMBOAT_LINE_ALSANCAK, "VAPUR");
    public static Vertex v6 = new Vertex(382, "Bayraklı Vapur İskelesi", TransportationType.STREAMBOAT_LINE_BAYRAKLI, "VAPUR");
    public static Vertex v7 = new Vertex(383, "Karşıyaka Vapur İskelesi", TransportationType.STREAMBOAT_LINE_KARSIYAKA, "VAPUR");
    public static Vertex v8 = new Vertex(384, "Bostanlı Vapur İskelesi", TransportationType.STREAMBOAT_LINE_BOSTANLI, "VAPUR");

}
