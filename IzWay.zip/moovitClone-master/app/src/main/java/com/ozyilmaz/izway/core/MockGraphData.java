package com.ozyilmaz.izway.core;


import static com.ozyilmaz.izway.core.MockDataMain.*;

public final class MockGraphData {

    public static Graph createAllEdgesToGraph(Graph graph) {
        int vertices = 387;

        /*777 Numaralı Otobüs Hattı Bağlantıları*/
        a1.CreateEdgeTo(a2, 3);
        a2.CreateEdgeTo(a1, 3);

        a2.CreateEdgeTo(a3, 3);
        a3.CreateEdgeTo(a2, 3);

        a3.CreateEdgeTo(a4, 3);
        a4.CreateEdgeTo(a3, 3);

        a5.CreateEdgeTo(a4, 3);
        a4.CreateEdgeTo(a5, 3);

        a5.CreateEdgeTo(a6, 3);
        a6.CreateEdgeTo(a5, 3);

        a6.CreateEdgeTo(a7, 3);
        a7.CreateEdgeTo(a6, 3);

        a7.CreateEdgeTo(a8, 3);
        a8.CreateEdgeTo(a7, 3);

        a8.CreateEdgeTo(a9, 3);
        a9.CreateEdgeTo(a8, 3);

        a9.CreateEdgeTo(a10, 3);
        a10.CreateEdgeTo(a9, 3);

        a10.CreateEdgeTo(a11, 3);
        a11.CreateEdgeTo(a10, 3);

        a11.CreateEdgeTo(a12, 3);
        a12.CreateEdgeTo(a11, 3);

        a12.CreateEdgeTo(a13, 3);
        a13.CreateEdgeTo(a12, 3);

        a13.CreateEdgeTo(a14, 3);
        a14.CreateEdgeTo(a13, 3);

        a14.CreateEdgeTo(a15, 3);
        a15.CreateEdgeTo(a14, 3);

        a15.CreateEdgeTo(a16, 3);
        a16.CreateEdgeTo(a15, 3);

        a16.CreateEdgeTo(a17, 3);
        a17.CreateEdgeTo(a16, 3);

        a17.CreateEdgeTo(a18, 3);
        a18.CreateEdgeTo(a17, 3);

        a18.CreateEdgeTo(a19, 3);
        a19.CreateEdgeTo(a18, 3);

        a19.CreateEdgeTo(a20, 3);
        a20.CreateEdgeTo(a19, 3);

        a20.CreateEdgeTo(a21, 3);
        a21.CreateEdgeTo(a20, 3);

        a21.CreateEdgeTo(a22, 3);
        a22.CreateEdgeTo(a21, 3);

        a22.CreateEdgeTo(a23, 3);
        a23.CreateEdgeTo(a22, 3);

        a23.CreateEdgeTo(a24, 3);
        a24.CreateEdgeTo(a23, 3);

        a24.CreateEdgeTo(a25, 3);
        a25.CreateEdgeTo(a24, 3);


//            /*969 Numaralı Otobüs Hattı Bağlantıları*/
        b1.CreateEdgeTo(b2, 3);
        b2.CreateEdgeTo(b1, 3);

        b2.CreateEdgeTo(b3, 3);
        b3.CreateEdgeTo(b2, 3);

        b3.CreateEdgeTo(b4, 3);
        b4.CreateEdgeTo(b3, 3);

        b4.CreateEdgeTo(b5, 3);
        b5.CreateEdgeTo(b4, 3);

        b5.CreateEdgeTo(b6, 3);
        b6.CreateEdgeTo(b5, 3);

        b6.CreateEdgeTo(b7, 3);
        b7.CreateEdgeTo(b6, 3);

        b7.CreateEdgeTo(b8, 3);
        b8.CreateEdgeTo(b7, 3);

        b8.CreateEdgeTo(b9, 3);
        b9.CreateEdgeTo(b8, 3);

        b9.CreateEdgeTo(b10, 3);
        b10.CreateEdgeTo(b9, 3);

        b10.CreateEdgeTo(b11, 3);
        b11.CreateEdgeTo(b10, 3);

        b11.CreateEdgeTo(b12, 3);
        b12.CreateEdgeTo(b11, 3);

        b12.CreateEdgeTo(b13, 3);
        b13.CreateEdgeTo(b12, 3);

        b13.CreateEdgeTo(b14, 3);
        b14.CreateEdgeTo(b13, 3);

//            /*551 Numaralı Otobüs Hattı Bağlantıları*/
        c1.CreateEdgeTo(c2, 3);
        c2.CreateEdgeTo(c1, 3);

        c2.CreateEdgeTo(c3, 3);
        c3.CreateEdgeTo(c2, 3);

        c3.CreateEdgeTo(c4, 3);
        c4.CreateEdgeTo(c3, 3);

        c4.CreateEdgeTo(c5, 3);
        c5.CreateEdgeTo(c4, 3);

        c5.CreateEdgeTo(c6, 3);
        c6.CreateEdgeTo(c5, 3);

        c6.CreateEdgeTo(c7, 3);
        c7.CreateEdgeTo(c6, 3);

        c7.CreateEdgeTo(c8, 3);
        c8.CreateEdgeTo(c7, 3);

        c8.CreateEdgeTo(c9, 3);
        c9.CreateEdgeTo(c8, 3);

        c9.CreateEdgeTo(c10, 3);
        c10.CreateEdgeTo(c9, 3);

        c10.CreateEdgeTo(c11, 3);
        c11.CreateEdgeTo(c10, 3);

        c11.CreateEdgeTo(c12, 3);
        c12.CreateEdgeTo(c11, 3);

        c12.CreateEdgeTo(c13, 3);
        c13.CreateEdgeTo(c12, 3);

        c13.CreateEdgeTo(c14, 3);
        c14.CreateEdgeTo(c13, 3);

        c14.CreateEdgeTo(c15, 3);
        c15.CreateEdgeTo(c14, 3);

        c15.CreateEdgeTo(c16, 3);
        c16.CreateEdgeTo(c15, 3);

        c16.CreateEdgeTo(c17, 3);
        c17.CreateEdgeTo(c16, 3);

        c17.CreateEdgeTo(c18, 3);
        c18.CreateEdgeTo(c17, 3);

        c18.CreateEdgeTo(c19, 3);
        c19.CreateEdgeTo(c18, 3);

        c19.CreateEdgeTo(c20, 3);
        c20.CreateEdgeTo(c19, 3);

        c20.CreateEdgeTo(c21, 3);
        c21.CreateEdgeTo(c20, 3);

        c21.CreateEdgeTo(c22, 3);
        c22.CreateEdgeTo(c21, 3);

        c22.CreateEdgeTo(c23, 3);
        c23.CreateEdgeTo(c22, 3);

        c23.CreateEdgeTo(c24, 3);
        c24.CreateEdgeTo(c23, 3);

        c24.CreateEdgeTo(c25, 3);
        c25.CreateEdgeTo(c24, 3);

        c25.CreateEdgeTo(c26, 3);
        c26.CreateEdgeTo(c25, 3);

        c26.CreateEdgeTo(c27, 3);
        c27.CreateEdgeTo(c26, 3);

        c27.CreateEdgeTo(c28, 3);
        c28.CreateEdgeTo(c27, 3);

        c28.CreateEdgeTo(c29, 3);
        c29.CreateEdgeTo(c28, 3);

        c29.CreateEdgeTo(c30, 3);
        c30.CreateEdgeTo(c29, 3);

        /*681 Numaralı Otobüs Hattı Bağlantıları*/
        d1.CreateEdgeTo(d2, 3);
        d2.CreateEdgeTo(d1, 3);

        d2.CreateEdgeTo(d3, 3);
        d3.CreateEdgeTo(d2, 3);

        d3.CreateEdgeTo(d4, 3);
        d4.CreateEdgeTo(d3, 3);

        d4.CreateEdgeTo(d5, 3);
        d5.CreateEdgeTo(d4, 3);

        d5.CreateEdgeTo(d6, 3);
        d6.CreateEdgeTo(d5, 3);

        d6.CreateEdgeTo(d7, 3);
        d7.CreateEdgeTo(d6, 3);

        d7.CreateEdgeTo(d8, 3);
        d8.CreateEdgeTo(d7, 3);

        d8.CreateEdgeTo(d9, 3);
        d9.CreateEdgeTo(d8, 3);

        d9.CreateEdgeTo(d10, 3);
        d10.CreateEdgeTo(d9, 3);

        d10.CreateEdgeTo(d11, 3);
        d11.CreateEdgeTo(d10, 3);

        d11.CreateEdgeTo(d12, 3);
        d12.CreateEdgeTo(d11, 3);

        d12.CreateEdgeTo(d13, 3);
        d13.CreateEdgeTo(d12, 3);

        d13.CreateEdgeTo(d14, 3);
        d14.CreateEdgeTo(d13, 3);

        d14.CreateEdgeTo(d15, 3);
        d15.CreateEdgeTo(d14, 3);

        d15.CreateEdgeTo(d16, 3);
        d16.CreateEdgeTo(d15, 3);

        d16.CreateEdgeTo(d17, 3);
        d17.CreateEdgeTo(d16, 3);

        d17.CreateEdgeTo(d18, 3);
        d18.CreateEdgeTo(d17, 3);

        d18.CreateEdgeTo(d19, 3);
        d19.CreateEdgeTo(d18, 3);

        d19.CreateEdgeTo(d20, 3);
        d20.CreateEdgeTo(d19, 3);

        d20.CreateEdgeTo(d21, 3);
        d21.CreateEdgeTo(d20, 3);

        /*963 Numaralı Otobüs Hattı Bağlantıları*/
        e1.CreateEdgeTo(e2, 3);
        e2.CreateEdgeTo(e1, 3);

        e2.CreateEdgeTo(e3, 3);
        e3.CreateEdgeTo(e2, 3);

        e3.CreateEdgeTo(e4, 3);
        e4.CreateEdgeTo(e3, 3);

        e4.CreateEdgeTo(e5, 3);
        e5.CreateEdgeTo(e4, 3);

        e5.CreateEdgeTo(e6, 3);
        e6.CreateEdgeTo(e5, 3);

        e6.CreateEdgeTo(e7, 3);
        e7.CreateEdgeTo(e6, 3);

        e7.CreateEdgeTo(e8, 3);
        e8.CreateEdgeTo(e7, 3);

        e8.CreateEdgeTo(e9, 3);
        e9.CreateEdgeTo(e8, 3);

        e9.CreateEdgeTo(e10, 3);
        e10.CreateEdgeTo(e9, 3);

        e10.CreateEdgeTo(e11, 3);
        e11.CreateEdgeTo(e10, 3);

        e11.CreateEdgeTo(e12, 3);
        e12.CreateEdgeTo(e11, 3);

        e12.CreateEdgeTo(e13, 3);
        e13.CreateEdgeTo(e12, 3);

        e13.CreateEdgeTo(e14, 3);
        e14.CreateEdgeTo(e13, 3);

        e14.CreateEdgeTo(e15, 3);
        e15.CreateEdgeTo(e14, 3);

        e15.CreateEdgeTo(e16, 3);
        e16.CreateEdgeTo(e15, 3);

        e16.CreateEdgeTo(e17, 3);
        e17.CreateEdgeTo(e16, 3);

        e17.CreateEdgeTo(e18, 3);
        e18.CreateEdgeTo(e17, 3);

        e18.CreateEdgeTo(e19, 3);
        e19.CreateEdgeTo(e18, 3);

        /*302 Numaralı Otobüs Hattı Bağlantıları*/
        f1.CreateEdgeTo(f2, 3);
        f2.CreateEdgeTo(f1, 3);

        f2.CreateEdgeTo(f3, 3);
        f3.CreateEdgeTo(f2, 3);

        f3.CreateEdgeTo(f4, 3);
        f4.CreateEdgeTo(f3, 3);

        f4.CreateEdgeTo(f5, 3);
        f5.CreateEdgeTo(f4, 3);

        f5.CreateEdgeTo(f6, 3);
        f6.CreateEdgeTo(f5, 3);

        f6.CreateEdgeTo(f7, 3);
        f7.CreateEdgeTo(f6, 3);

        f7.CreateEdgeTo(f8, 3);
        f8.CreateEdgeTo(f7, 3);

        f8.CreateEdgeTo(f9, 3);
        f9.CreateEdgeTo(f8, 3);

        f9.CreateEdgeTo(f10, 3);
        f10.CreateEdgeTo(f9, 3);

        f10.CreateEdgeTo(f11, 3);
        f11.CreateEdgeTo(f10, 3);

        f11.CreateEdgeTo(f12, 3);
        f12.CreateEdgeTo(f11, 3);

        f12.CreateEdgeTo(f13, 3);
        f13.CreateEdgeTo(f12, 3);

        f13.CreateEdgeTo(f14, 3);
        f14.CreateEdgeTo(f13, 3);

        f14.CreateEdgeTo(f15, 3);
        f15.CreateEdgeTo(f14, 3);

        f15.CreateEdgeTo(f16, 3);
        f16.CreateEdgeTo(f15, 3);

        f16.CreateEdgeTo(f17, 3);
        f17.CreateEdgeTo(f16, 3);

        f17.CreateEdgeTo(f18, 3);
        f18.CreateEdgeTo(f17, 3);

        f18.CreateEdgeTo(f19, 3);
        f19.CreateEdgeTo(f18, 3);

        f19.CreateEdgeTo(f20, 3);
        f20.CreateEdgeTo(f19, 3);

        f20.CreateEdgeTo(f21, 3);
        f21.CreateEdgeTo(f20, 3);

        f21.CreateEdgeTo(f22, 3);
        f22.CreateEdgeTo(f21, 3);

        /*304 Numaralı Otobüs Hattı Bağlantıları*/
        g1.CreateEdgeTo(g2, 3);
        g2.CreateEdgeTo(g1, 3);

        g2.CreateEdgeTo(g3, 3);
        g3.CreateEdgeTo(g2, 3);

        g3.CreateEdgeTo(g4, 3);
        g4.CreateEdgeTo(g3, 3);

        g4.CreateEdgeTo(g5, 3);
        g5.CreateEdgeTo(g4, 3);

        g5.CreateEdgeTo(g6, 3);
        g6.CreateEdgeTo(g5, 3);

        g6.CreateEdgeTo(g7, 3);
        g7.CreateEdgeTo(g6, 3);

        g7.CreateEdgeTo(g8, 3);
        g8.CreateEdgeTo(g7, 3);

        g8.CreateEdgeTo(g9, 3);
        g9.CreateEdgeTo(g8, 3);

        g9.CreateEdgeTo(g10, 3);
        g10.CreateEdgeTo(g9, 3);

        g10.CreateEdgeTo(g11, 3);
        g11.CreateEdgeTo(g10, 3);

        g11.CreateEdgeTo(g12, 3);
        g12.CreateEdgeTo(g11, 3);

        g12.CreateEdgeTo(g13, 3);
        g13.CreateEdgeTo(g12, 3);

        g13.CreateEdgeTo(g14, 3);
        g14.CreateEdgeTo(g13, 3);

        g14.CreateEdgeTo(g15, 3);
        g15.CreateEdgeTo(g14, 3);

        g15.CreateEdgeTo(g16, 3);
        g16.CreateEdgeTo(g15, 3);

        g16.CreateEdgeTo(g17, 3);
        g17.CreateEdgeTo(g16, 3);

        g17.CreateEdgeTo(g18, 3);
        g18.CreateEdgeTo(g17, 3);

        g18.CreateEdgeTo(g19, 3);
        g19.CreateEdgeTo(g18, 3);

        /*470 Numaralı Otobüs Hattı Bağlantıları*/
        h1.CreateEdgeTo(h2, 3);
        h2.CreateEdgeTo(h1, 3);

        h2.CreateEdgeTo(h3, 3);
        h3.CreateEdgeTo(h2, 3);

        h3.CreateEdgeTo(h4, 3);
        h4.CreateEdgeTo(h3, 3);

        h4.CreateEdgeTo(h5, 3);
        h5.CreateEdgeTo(h4, 3);

        h5.CreateEdgeTo(h6, 3);
        h6.CreateEdgeTo(h5, 3);

        h6.CreateEdgeTo(h7, 3);
        h7.CreateEdgeTo(h6, 3);

        h7.CreateEdgeTo(h8, 3);
        h8.CreateEdgeTo(h7, 3);

        h8.CreateEdgeTo(h9, 3);
        h9.CreateEdgeTo(h8, 3);

        h9.CreateEdgeTo(h10, 3);
        h10.CreateEdgeTo(h9, 3);

        h10.CreateEdgeTo(h11, 3);
        h11.CreateEdgeTo(h10, 3);

        h11.CreateEdgeTo(h12, 3);
        h12.CreateEdgeTo(h11, 3);

        h12.CreateEdgeTo(h13, 3);
        h13.CreateEdgeTo(h12, 3);

        h13.CreateEdgeTo(h14, 3);
        h14.CreateEdgeTo(h13, 3);

        h14.CreateEdgeTo(h15, 3);
        h15.CreateEdgeTo(h14, 3);

        h15.CreateEdgeTo(h16, 3);
        h16.CreateEdgeTo(h15, 3);

        h16.CreateEdgeTo(h17, 3);
        h17.CreateEdgeTo(h16, 3);

        h17.CreateEdgeTo(h18, 3);
        h18.CreateEdgeTo(h17, 3);

        h18.CreateEdgeTo(h19, 3);
        h19.CreateEdgeTo(h18, 3);

        h19.CreateEdgeTo(h20, 3);
        h20.CreateEdgeTo(h19, 3);

        h20.CreateEdgeTo(h21, 3);
        h21.CreateEdgeTo(h20, 3);

        h21.CreateEdgeTo(h22, 3);
        h22.CreateEdgeTo(h21, 3);

        h22.CreateEdgeTo(h23, 3);
        h23.CreateEdgeTo(h22, 3);

        h23.CreateEdgeTo(h24, 3);
        h24.CreateEdgeTo(h23, 3);

        h24.CreateEdgeTo(h25, 3);
        h25.CreateEdgeTo(h24, 3);

        h25.CreateEdgeTo(h26, 3);
        h26.CreateEdgeTo(h25, 3);

        /*921 Numaralı Otobüs Hattı Bağlantıları*/
        i1.CreateEdgeTo(i2, 3);
        i2.CreateEdgeTo(i1, 3);

        i2.CreateEdgeTo(i3, 3);
        i3.CreateEdgeTo(i2, 3);

        i3.CreateEdgeTo(i4, 3);
        i4.CreateEdgeTo(i3, 3);

        i4.CreateEdgeTo(i5, 3);
        i5.CreateEdgeTo(i4, 3);

        i5.CreateEdgeTo(i6, 3);
        i6.CreateEdgeTo(i5, 3);

        i6.CreateEdgeTo(i7, 3);
        i7.CreateEdgeTo(i6, 3);

        i7.CreateEdgeTo(i8, 3);
        i8.CreateEdgeTo(i7, 3);

        i8.CreateEdgeTo(i9, 3);
        i9.CreateEdgeTo(i8, 3);

        i9.CreateEdgeTo(i10, 3);
        i10.CreateEdgeTo(i9, 3);

        /*912 Numaralı Otobüs Hattı Bağlantıları*/
        j1.CreateEdgeTo(j2, 3);
        j2.CreateEdgeTo(j1, 3);

        j2.CreateEdgeTo(j3, 3);
        j3.CreateEdgeTo(j2, 3);

        j3.CreateEdgeTo(j4, 3);
        j4.CreateEdgeTo(j3, 3);

        j4.CreateEdgeTo(j5, 3);
        j5.CreateEdgeTo(j4, 3);

        j5.CreateEdgeTo(j6, 3);
        j6.CreateEdgeTo(j5, 3);

        j6.CreateEdgeTo(j7, 3);
        j7.CreateEdgeTo(j6, 3);

        j7.CreateEdgeTo(j8, 3);
        j8.CreateEdgeTo(j7, 3);

        j8.CreateEdgeTo(j9, 3);
        j9.CreateEdgeTo(j8, 3);

        j9.CreateEdgeTo(j10, 3);
        j10.CreateEdgeTo(j9, 3);

        j10.CreateEdgeTo(j11, 3);
        j11.CreateEdgeTo(j10, 3);

        j11.CreateEdgeTo(j12, 3);
        j12.CreateEdgeTo(j11, 3);

        j12.CreateEdgeTo(j13, 3);
        j13.CreateEdgeTo(j12, 3);

        j13.CreateEdgeTo(j14, 3);
        j14.CreateEdgeTo(j13, 3);

        j14.CreateEdgeTo(j15, 3);
        j15.CreateEdgeTo(j14, 3);

        j15.CreateEdgeTo(j16, 3);
        j16.CreateEdgeTo(j15, 3);

        j16.CreateEdgeTo(j17, 3);
        j17.CreateEdgeTo(j16, 3);

        j17.CreateEdgeTo(j18, 3);
        j18.CreateEdgeTo(j17, 3);

        j18.CreateEdgeTo(j19, 3);
        j19.CreateEdgeTo(j18, 3);

        j19.CreateEdgeTo(j20, 3);
        j20.CreateEdgeTo(j19, 3);

        j20.CreateEdgeTo(j21, 3);
        j21.CreateEdgeTo(j20, 3);

        j21.CreateEdgeTo(j22, 3);
        j22.CreateEdgeTo(j21, 3);

        j22.CreateEdgeTo(j23, 3);
        j23.CreateEdgeTo(j22, 3);

        /*543 Numaralı Otobüs Hattı Bağlantıları*/
        k1.CreateEdgeTo(k2, 3);
        k2.CreateEdgeTo(k1, 3);

        k2.CreateEdgeTo(k3, 3);
        k3.CreateEdgeTo(k2, 3);

        k3.CreateEdgeTo(k4, 3);
        k4.CreateEdgeTo(k3, 3);

        k4.CreateEdgeTo(k5, 3);
        k5.CreateEdgeTo(k4, 3);

        k5.CreateEdgeTo(k6, 3);
        k6.CreateEdgeTo(k5, 3);

        k6.CreateEdgeTo(k7, 3);
        k7.CreateEdgeTo(k6, 3);

        k7.CreateEdgeTo(k8, 3);
        k8.CreateEdgeTo(k7, 3);

        k8.CreateEdgeTo(k9, 3);
        k9.CreateEdgeTo(k8, 3);

        k9.CreateEdgeTo(k10, 3);
        k10.CreateEdgeTo(k9, 3);

        k10.CreateEdgeTo(k11, 3);
        k11.CreateEdgeTo(k10, 3);

        k11.CreateEdgeTo(k12, 3);
        k12.CreateEdgeTo(k11, 3);

        k12.CreateEdgeTo(k13, 3);
        k13.CreateEdgeTo(k12, 3);

        k13.CreateEdgeTo(k14, 3);
        k14.CreateEdgeTo(k13, 3);

        k14.CreateEdgeTo(k15, 3);
        k15.CreateEdgeTo(k14, 3);

        k15.CreateEdgeTo(k16, 3);
        k16.CreateEdgeTo(k15, 3);

        k16.CreateEdgeTo(k17, 3);
        k17.CreateEdgeTo(k16, 3);

        k17.CreateEdgeTo(k18, 3);
        k18.CreateEdgeTo(k17, 3);

        k18.CreateEdgeTo(k19, 3);
        k19.CreateEdgeTo(k18, 3);

        k19.CreateEdgeTo(k20, 3);
        k20.CreateEdgeTo(k19, 3);

        k20.CreateEdgeTo(k21, 3);
        k21.CreateEdgeTo(k20, 3);

        k21.CreateEdgeTo(k22, 3);
        k22.CreateEdgeTo(k21, 3);

        /*680 Numaralı Otobüs Hattı Bağlantıları*/
        n1.CreateEdgeTo(n2, 3);
        n2.CreateEdgeTo(n1, 3);

        n2.CreateEdgeTo(n3, 3);
        n3.CreateEdgeTo(n2, 3);

        n3.CreateEdgeTo(n4, 3);
        n4.CreateEdgeTo(n3, 3);

        n4.CreateEdgeTo(n5, 3);
        n5.CreateEdgeTo(n4, 3);

        n5.CreateEdgeTo(n6, 3);
        n6.CreateEdgeTo(n5, 3);

        n6.CreateEdgeTo(n7, 3);
        n7.CreateEdgeTo(n6, 3);

        n7.CreateEdgeTo(n8, 3);
        n8.CreateEdgeTo(n7, 3);

        n8.CreateEdgeTo(n9, 3);
        n9.CreateEdgeTo(n8, 3);

        n9.CreateEdgeTo(n10, 3);
        n10.CreateEdgeTo(n9, 3);

        n10.CreateEdgeTo(n11, 3);
        n11.CreateEdgeTo(n10, 3);

        n11.CreateEdgeTo(n12, 3);
        n12.CreateEdgeTo(n11, 3);

        n12.CreateEdgeTo(n13, 3);
        n13.CreateEdgeTo(n12, 3);

        n13.CreateEdgeTo(n14, 3);
        n14.CreateEdgeTo(n13, 3);

        n14.CreateEdgeTo(n15, 3);
        n15.CreateEdgeTo(n14, 3);

        n15.CreateEdgeTo(n16, 3);
        n16.CreateEdgeTo(n15, 3);

        n16.CreateEdgeTo(n17, 3);
        n17.CreateEdgeTo(n16, 3);

        n17.CreateEdgeTo(n18, 3);
        n18.CreateEdgeTo(n17, 3);

        n18.CreateEdgeTo(n19, 3);
        n19.CreateEdgeTo(n18, 3);

        n19.CreateEdgeTo(n20, 3);
        n20.CreateEdgeTo(n19, 3);

        n20.CreateEdgeTo(n21, 3);
        n21.CreateEdgeTo(n20, 3);

        n21.CreateEdgeTo(n22, 3);
        n22.CreateEdgeTo(n21, 3);

        /*691 Numaralı Otobüs Hattı Bağlantıları*/
        m1.CreateEdgeTo(m2, 3);
        m2.CreateEdgeTo(m1, 3);

        m2.CreateEdgeTo(m3, 3);
        m3.CreateEdgeTo(m2, 3);

        m3.CreateEdgeTo(m4, 3);
        m4.CreateEdgeTo(m3, 3);

        m4.CreateEdgeTo(m5, 3);
        m5.CreateEdgeTo(m4, 3);

        m5.CreateEdgeTo(m6, 3);
        m6.CreateEdgeTo(m5, 3);

        m6.CreateEdgeTo(m7, 3);
        m7.CreateEdgeTo(m6, 3);

        m7.CreateEdgeTo(m8, 3);
        m8.CreateEdgeTo(m7, 3);

        m8.CreateEdgeTo(m9, 3);
        m9.CreateEdgeTo(m8, 3);

        m9.CreateEdgeTo(m10, 3);
        m10.CreateEdgeTo(m9, 3);

        m10.CreateEdgeTo(m11, 3);
        m11.CreateEdgeTo(m10, 3);

        m11.CreateEdgeTo(m12, 3);
        m12.CreateEdgeTo(m11, 3);

        m12.CreateEdgeTo(m13, 3);
        m13.CreateEdgeTo(m12, 3);

        m13.CreateEdgeTo(m14, 3);
        m14.CreateEdgeTo(m13, 3);

        m14.CreateEdgeTo(m15, 3);
        m15.CreateEdgeTo(m14, 3);

        m15.CreateEdgeTo(m16, 3);
        m16.CreateEdgeTo(m15, 3);

        m16.CreateEdgeTo(m17, 3);
        m17.CreateEdgeTo(m16, 3);

        m17.CreateEdgeTo(m18, 3);
        m18.CreateEdgeTo(m17, 3);

        m18.CreateEdgeTo(m19, 3);
        m19.CreateEdgeTo(m18, 3);

        m19.CreateEdgeTo(m20, 3);
        m20.CreateEdgeTo(m19, 3);

        m20.CreateEdgeTo(m21, 3);
        m21.CreateEdgeTo(m20, 3);

        m21.CreateEdgeTo(m22, 3);
        m22.CreateEdgeTo(m21, 3);

        m22.CreateEdgeTo(m23, 3);
        m23.CreateEdgeTo(m22, 3);

        m23.CreateEdgeTo(m24, 3);
        m24.CreateEdgeTo(m23, 3);

        m24.CreateEdgeTo(m25, 3);
        m25.CreateEdgeTo(m24, 3);

        m25.CreateEdgeTo(m26, 3);
        m26.CreateEdgeTo(m25, 3);

        m26.CreateEdgeTo(m27, 3);
        m27.CreateEdgeTo(m26, 3);

        m27.CreateEdgeTo(m28, 3);
        m28.CreateEdgeTo(m27, 3);

        m28.CreateEdgeTo(m29, 3);
        m29.CreateEdgeTo(m28, 3);

        m29.CreateEdgeTo(m30, 3);
        m30.CreateEdgeTo(m29, 3);

        m30.CreateEdgeTo(m31, 3);
        m31.CreateEdgeTo(m30, 3);

        m31.CreateEdgeTo(m32, 3);
        m32.CreateEdgeTo(m31, 3);

        m32.CreateEdgeTo(m33, 3);
        m33.CreateEdgeTo(m32, 3);

        m33.CreateEdgeTo(m34, 3);
        m34.CreateEdgeTo(m33, 3);

        m34.CreateEdgeTo(m35, 3);
        m35.CreateEdgeTo(m34, 3);

        m35.CreateEdgeTo(m36, 3);
        m36.CreateEdgeTo(m35, 3);

        m36.CreateEdgeTo(m37, 3);
        m37.CreateEdgeTo(m36, 3);

        m37.CreateEdgeTo(m38, 3);
        m38.CreateEdgeTo(m37, 3);

        /* Karşıyaka Tramvay Hattı Durakları*/
        x1.CreateEdgeTo(x2, TransportationType.TRAM.getValue());
        x2.CreateEdgeTo(x1, TransportationType.TRAM.getValue());

        x2.CreateEdgeTo(x3, TransportationType.TRAM.getValue());
        x3.CreateEdgeTo(x2, TransportationType.TRAM.getValue());

        x3.CreateEdgeTo(x4, TransportationType.TRAM.getValue());
        x4.CreateEdgeTo(x3, TransportationType.TRAM.getValue());

        x4.CreateEdgeTo(x5, TransportationType.TRAM.getValue());
        x5.CreateEdgeTo(x4, TransportationType.TRAM.getValue());

        x5.CreateEdgeTo(x6, TransportationType.TRAM.getValue());
        x6.CreateEdgeTo(x5, TransportationType.TRAM.getValue());

        x6.CreateEdgeTo(x7, TransportationType.TRAM.getValue());
        x7.CreateEdgeTo(x6, TransportationType.TRAM.getValue());

        x7.CreateEdgeTo(x8, TransportationType.TRAM.getValue());
        x8.CreateEdgeTo(x7, TransportationType.TRAM.getValue());

        x8.CreateEdgeTo(x9, TransportationType.TRAM.getValue());
        x9.CreateEdgeTo(x8, TransportationType.TRAM.getValue());

        x9.CreateEdgeTo(x10, TransportationType.TRAM.getValue());
        x10.CreateEdgeTo(x9, TransportationType.TRAM.getValue());

        x10.CreateEdgeTo(x11, TransportationType.TRAM.getValue());
        x11.CreateEdgeTo(x10, TransportationType.TRAM.getValue());

        x11.CreateEdgeTo(x12, TransportationType.TRAM.getValue());
        x12.CreateEdgeTo(x11, TransportationType.TRAM.getValue());

        x12.CreateEdgeTo(x13, TransportationType.TRAM.getValue());
        x13.CreateEdgeTo(x12, TransportationType.TRAM.getValue());

        x13.CreateEdgeTo(x14, TransportationType.TRAM.getValue());
        x14.CreateEdgeTo(x13, TransportationType.TRAM.getValue());

        /* Konak Tramvay Hattı Durakları */
        y1.CreateEdgeTo(y2, TransportationType.TRAM.getValue());
        y2.CreateEdgeTo(y1, TransportationType.TRAM.getValue());

        y2.CreateEdgeTo(y3, TransportationType.TRAM.getValue());
        y3.CreateEdgeTo(y2, TransportationType.TRAM.getValue());

        y3.CreateEdgeTo(y4, TransportationType.TRAM.getValue());
        y4.CreateEdgeTo(y3, TransportationType.TRAM.getValue());

        y4.CreateEdgeTo(y5, TransportationType.TRAM.getValue());
        y5.CreateEdgeTo(y4, TransportationType.TRAM.getValue());

        y5.CreateEdgeTo(y6, TransportationType.TRAM.getValue());
        y6.CreateEdgeTo(y5, TransportationType.TRAM.getValue());

        y6.CreateEdgeTo(y7, TransportationType.TRAM.getValue());
        y7.CreateEdgeTo(y6, TransportationType.TRAM.getValue());

        y7.CreateEdgeTo(y8, TransportationType.TRAM.getValue());
        y8.CreateEdgeTo(y7, TransportationType.TRAM.getValue());

        y8.CreateEdgeTo(y9, TransportationType.TRAM.getValue());
        y9.CreateEdgeTo(y8, TransportationType.TRAM.getValue());

        y9.CreateEdgeTo(y10, TransportationType.TRAM.getValue());
        y10.CreateEdgeTo(y9, TransportationType.TRAM.getValue());

        y10.CreateEdgeTo(y11, TransportationType.TRAM.getValue());
        y11.CreateEdgeTo(y10, TransportationType.TRAM.getValue());

        y11.CreateEdgeTo(y12, TransportationType.TRAM.getValue());
        y12.CreateEdgeTo(y11, TransportationType.TRAM.getValue());

        y12.CreateEdgeTo(y13, TransportationType.TRAM.getValue());
        y13.CreateEdgeTo(y12, TransportationType.TRAM.getValue());

        y13.CreateEdgeTo(y14, TransportationType.TRAM.getValue());
        y14.CreateEdgeTo(y13, TransportationType.TRAM.getValue());

        y14.CreateEdgeTo(y15, TransportationType.TRAM.getValue());
        y15.CreateEdgeTo(y14, TransportationType.TRAM.getValue());

        y15.CreateEdgeTo(y16, TransportationType.TRAM.getValue());
        y16.CreateEdgeTo(y15, TransportationType.TRAM.getValue());

        /* Metro Durakları */
        w1.CreateEdgeTo(w2, TransportationType.METRO.getValue());
        w2.CreateEdgeTo(w1, TransportationType.METRO.getValue());

        w2.CreateEdgeTo(w3, TransportationType.METRO.getValue());
        w3.CreateEdgeTo(w2, TransportationType.METRO.getValue());

        w3.CreateEdgeTo(w4, TransportationType.METRO.getValue());
        w4.CreateEdgeTo(w3, TransportationType.METRO.getValue());

        w4.CreateEdgeTo(w5, TransportationType.METRO.getValue());
        w5.CreateEdgeTo(w4, TransportationType.METRO.getValue());

        w5.CreateEdgeTo(w6, TransportationType.METRO.getValue());
        w6.CreateEdgeTo(w5, TransportationType.METRO.getValue());

        w6.CreateEdgeTo(w7, TransportationType.METRO.getValue());
        w7.CreateEdgeTo(w6, TransportationType.METRO.getValue());

        w7.CreateEdgeTo(w8, TransportationType.METRO.getValue());
        w8.CreateEdgeTo(w7, TransportationType.METRO.getValue());

        w8.CreateEdgeTo(w9, TransportationType.METRO.getValue());
        w9.CreateEdgeTo(w8, TransportationType.METRO.getValue());

        w9.CreateEdgeTo(w10, TransportationType.METRO.getValue());
        w10.CreateEdgeTo(w9, TransportationType.METRO.getValue());

        w10.CreateEdgeTo(w11, TransportationType.METRO.getValue());
        w11.CreateEdgeTo(w10, TransportationType.METRO.getValue());

        w11.CreateEdgeTo(w12, TransportationType.METRO.getValue());
        w12.CreateEdgeTo(w11, TransportationType.METRO.getValue());

        w12.CreateEdgeTo(w13, TransportationType.METRO.getValue());
        w13.CreateEdgeTo(w12, TransportationType.METRO.getValue());

        w13.CreateEdgeTo(w14, TransportationType.METRO.getValue());
        w14.CreateEdgeTo(w13, TransportationType.METRO.getValue());

        w14.CreateEdgeTo(w15, TransportationType.METRO.getValue());
        w15.CreateEdgeTo(w14, TransportationType.METRO.getValue());

        w15.CreateEdgeTo(w16, TransportationType.METRO.getValue());
        w16.CreateEdgeTo(w15, TransportationType.METRO.getValue());

        w16.CreateEdgeTo(w17, TransportationType.METRO.getValue());
        w17.CreateEdgeTo(w16, TransportationType.METRO.getValue());

        /* İzban Durakları */
        p1.CreateEdgeTo(p2, TransportationType.IZBAN.getValue());
        p2.CreateEdgeTo(p1, TransportationType.IZBAN.getValue());

        p2.CreateEdgeTo(p3, TransportationType.IZBAN.getValue());
        p3.CreateEdgeTo(p2, TransportationType.IZBAN.getValue());

        p3.CreateEdgeTo(p4, TransportationType.IZBAN.getValue());
        p4.CreateEdgeTo(p3, TransportationType.IZBAN.getValue());

        p4.CreateEdgeTo(p5, TransportationType.IZBAN.getValue());
        p5.CreateEdgeTo(p4, TransportationType.IZBAN.getValue());

        p5.CreateEdgeTo(p6, TransportationType.IZBAN.getValue());
        p6.CreateEdgeTo(p5, TransportationType.IZBAN.getValue());

        p6.CreateEdgeTo(p7, TransportationType.IZBAN.getValue());
        p7.CreateEdgeTo(p6, TransportationType.IZBAN.getValue());

        p7.CreateEdgeTo(p8, TransportationType.IZBAN.getValue());
        p8.CreateEdgeTo(p7, TransportationType.IZBAN.getValue());

        p8.CreateEdgeTo(p9, TransportationType.IZBAN.getValue());
        p9.CreateEdgeTo(p8, TransportationType.IZBAN.getValue());

        p9.CreateEdgeTo(p10, TransportationType.IZBAN.getValue());
        p10.CreateEdgeTo(p9, TransportationType.IZBAN.getValue());

        p10.CreateEdgeTo(p11, TransportationType.IZBAN.getValue());
        p11.CreateEdgeTo(p10, TransportationType.IZBAN.getValue());

        p11.CreateEdgeTo(p12, TransportationType.IZBAN.getValue());
        p12.CreateEdgeTo(p11, TransportationType.IZBAN.getValue());

        p12.CreateEdgeTo(p13, TransportationType.IZBAN.getValue());
        p13.CreateEdgeTo(p12, TransportationType.IZBAN.getValue());

        p13.CreateEdgeTo(p14, TransportationType.IZBAN.getValue());
        p14.CreateEdgeTo(p13, TransportationType.IZBAN.getValue());

        p14.CreateEdgeTo(p15, TransportationType.IZBAN.getValue());
        p15.CreateEdgeTo(p14, TransportationType.IZBAN.getValue());

        p15.CreateEdgeTo(p16, TransportationType.IZBAN.getValue());
        p16.CreateEdgeTo(p15, TransportationType.IZBAN.getValue());

        p16.CreateEdgeTo(p17, TransportationType.IZBAN.getValue());
        p17.CreateEdgeTo(p16, TransportationType.IZBAN.getValue());

        p17.CreateEdgeTo(p18, TransportationType.IZBAN.getValue());
        p18.CreateEdgeTo(p17, TransportationType.IZBAN.getValue());

        p18.CreateEdgeTo(p19, TransportationType.IZBAN.getValue());
        p19.CreateEdgeTo(p18, TransportationType.IZBAN.getValue());

        p19.CreateEdgeTo(p20, TransportationType.IZBAN.getValue());
        p20.CreateEdgeTo(p19, TransportationType.IZBAN.getValue());

        p20.CreateEdgeTo(p21, TransportationType.IZBAN.getValue());
        p21.CreateEdgeTo(p20, TransportationType.IZBAN.getValue());

        p21.CreateEdgeTo(p22, TransportationType.IZBAN.getValue());
        p22.CreateEdgeTo(p21, TransportationType.IZBAN.getValue());

        p22.CreateEdgeTo(p23, TransportationType.IZBAN.getValue());
        p23.CreateEdgeTo(p22, TransportationType.IZBAN.getValue());

        p23.CreateEdgeTo(p24, TransportationType.IZBAN.getValue());
        p24.CreateEdgeTo(p23, TransportationType.IZBAN.getValue());

        p24.CreateEdgeTo(p25, TransportationType.IZBAN.getValue());
        p25.CreateEdgeTo(p24, TransportationType.IZBAN.getValue());

        p25.CreateEdgeTo(p26, TransportationType.IZBAN.getValue());
        m26.CreateEdgeTo(m25, TransportationType.IZBAN.getValue());

        p26.CreateEdgeTo(p27, TransportationType.IZBAN.getValue());
        p27.CreateEdgeTo(p26, TransportationType.IZBAN.getValue());

        p27.CreateEdgeTo(p28, TransportationType.IZBAN.getValue());
        p28.CreateEdgeTo(p27, TransportationType.IZBAN.getValue());

        p28.CreateEdgeTo(p29, TransportationType.IZBAN.getValue());
        p29.CreateEdgeTo(p28, TransportationType.IZBAN.getValue());

        p29.CreateEdgeTo(p30, TransportationType.IZBAN.getValue());
        p30.CreateEdgeTo(p29, TransportationType.IZBAN.getValue());

        p30.CreateEdgeTo(p31, TransportationType.IZBAN.getValue());
        p31.CreateEdgeTo(p30, TransportationType.IZBAN.getValue());

        p31.CreateEdgeTo(p32, TransportationType.IZBAN.getValue());
        p32.CreateEdgeTo(p31, TransportationType.IZBAN.getValue());

        p32.CreateEdgeTo(p33, TransportationType.IZBAN.getValue());
        p33.CreateEdgeTo(p32, TransportationType.IZBAN.getValue());

        p33.CreateEdgeTo(p34, TransportationType.IZBAN.getValue());
        p34.CreateEdgeTo(p33, TransportationType.IZBAN.getValue());

        p34.CreateEdgeTo(p35, TransportationType.IZBAN.getValue());
        p35.CreateEdgeTo(p34, TransportationType.IZBAN.getValue());

        p35.CreateEdgeTo(p36, TransportationType.IZBAN.getValue());
        p36.CreateEdgeTo(p35, TransportationType.IZBAN.getValue());

        p36.CreateEdgeTo(p37, TransportationType.IZBAN.getValue());
        p37.CreateEdgeTo(p36, TransportationType.IZBAN.getValue());

        p37.CreateEdgeTo(p38, TransportationType.IZBAN.getValue());
        p38.CreateEdgeTo(p37, TransportationType.IZBAN.getValue());

        p38.CreateEdgeTo(p39, TransportationType.IZBAN.getValue());
        p39.CreateEdgeTo(p38, TransportationType.IZBAN.getValue());

        p39.CreateEdgeTo(p40, TransportationType.IZBAN.getValue());
        p40.CreateEdgeTo(p39, TransportationType.IZBAN.getValue());

        p40.CreateEdgeTo(p41, TransportationType.IZBAN.getValue());
        p41.CreateEdgeTo(p40, TransportationType.IZBAN.getValue());
//
//        /* Bazı birleşme noktalarını eşitleme*/
//        /*Bostanlı Aktarma Merkezi Birleşim*/

        a23.CreateEdgeTo(i1, 0);
        i1.CreateEdgeTo(a23, 0);

        a23.CreateEdgeTo(k1, 0);
        k1.CreateEdgeTo(a23, 0);

        a23.CreateEdgeTo(x10, 0);
        x10.CreateEdgeTo(a23, 0);

        a23.CreateEdgeTo(v8, 0);
        v8.CreateEdgeTo(a23, 0);

//
//        /*Halkapınar Aktarma Merkezi Birleşim*/
        k22.CreateEdgeTo(y1, 0);
        y1.CreateEdgeTo(k22, 0);

        k22.CreateEdgeTo(w7, 0);
        w7.CreateEdgeTo(k22, 0);

        k22.CreateEdgeTo(p22, 0);
        p22.CreateEdgeTo(k22, 0);
//
//        /*Konak Aktarma Merkezi Birleşim*/

        f22.CreateEdgeTo(g19, 0);
        g19.CreateEdgeTo(f22, 0);

        f22.CreateEdgeTo(y7, 0);
        y7.CreateEdgeTo(f22, 0);

        f22.CreateEdgeTo(w11, 0);
        w11.CreateEdgeTo(f22, 0);
//
//        /*Fahrettin Altay Aktarma Merkezi Birleşim*/

        b14.CreateEdgeTo(d5, 0);
        d5.CreateEdgeTo(b14, 0);

        b14.CreateEdgeTo(y16, 0);
        y16.CreateEdgeTo(b14, 0);
        b14.CreateEdgeTo(w17, 0);
        w17.CreateEdgeTo(b14, 0);
        b14.CreateEdgeTo(c26, 0);
        c26.CreateEdgeTo(b14, 0);

//
//        /*Montrö*/
        d21.CreateEdgeTo(h26, 0);
        h26.CreateEdgeTo(d21, 0);
        d21.CreateEdgeTo(n22, 0);
        n22.CreateEdgeTo(d21, 0);

        d21.CreateEdgeTo(m38, 0);
        m38.CreateEdgeTo(d21, 0);

        d21.CreateEdgeTo(y5, 0);
        y5.CreateEdgeTo(d21, 0);

//
//        /*Alsancak Garı*/
        e17.CreateEdgeTo(i10, 0);
        i10.CreateEdgeTo(e17, 0);

        e17.CreateEdgeTo(j23, 0);
        j23.CreateEdgeTo(e17, 0);

        e17.CreateEdgeTo(y2, 0);
        y2.CreateEdgeTo(e17, 0);

        e17.CreateEdgeTo(p21, 0);
        p21.CreateEdgeTo(e17, 0);

//
//        /* Karşıyaka İskele */
        v7.CreateEdgeTo(a25, 0);
        a25.CreateEdgeTo(v7, 0);

        v7.CreateEdgeTo(i3, 0);
        i3.CreateEdgeTo(v7, 0);

        v7.CreateEdgeTo(k3, 0);
        k3.CreateEdgeTo(v7, 0);

        v7.CreateEdgeTo(x13, 0);
        x13.CreateEdgeTo(v7, 0);

//
//        /* Turan */
        i7.CreateEdgeTo(j20, 0);
        j20.CreateEdgeTo(i7, 0);

        i7.CreateEdgeTo(k7, 0);
        k7.CreateEdgeTo(i7, 0);

        i7.CreateEdgeTo(p25, 0);
        p25.CreateEdgeTo(i7, 0);

//
//        /* Bayraklı Üst Geçit */
        i8.CreateEdgeTo(j21, 0);
        j21.CreateEdgeTo(i8, 0);

        i8.CreateEdgeTo(k8, 0);
        k8.CreateEdgeTo(i8, 0);
//
//        /* Liman */
        e18.CreateEdgeTo(i9, 0);
        i9.CreateEdgeTo(e18, 0);
        e18.CreateEdgeTo(j22, 0);
        j22.CreateEdgeTo(e18, 0);

//
//        /* Yağhaneler */
        m33.CreateEdgeTo(n17, 0);
        n17.CreateEdgeTo(m33, 0);
        m33.CreateEdgeTo(h21, 0);
        h21.CreateEdgeTo(m33, 0);
//
//        /* Eşrefpaşa*/
        m34.CreateEdgeTo(n18, 0);
        n18.CreateEdgeTo(m34, 0);
        m34.CreateEdgeTo(h22, 0);
        h22.CreateEdgeTo(m34, 0);
//
//        /* Koruluk */
        m35.CreateEdgeTo(n19, 0);
        n19.CreateEdgeTo(m35, 0);
        m35.CreateEdgeTo(h23, 0);
        h23.CreateEdgeTo(m35, 0);
        m35.CreateEdgeTo(d18, 0);
        d18.CreateEdgeTo(m35, 0);

//
//        /* Kestelli */
        m36.CreateEdgeTo(n20, 0);
        n20.CreateEdgeTo(m36, 0);
        m36.CreateEdgeTo(h24, 0);
        h24.CreateEdgeTo(m36, 0);
        m36.CreateEdgeTo(d19, 0);
        d19.CreateEdgeTo(m36, 0);
//
//        /* Mez.Başı */
        m37.CreateEdgeTo(n21, 0);
        n21.CreateEdgeTo(m37, 0);
        m37.CreateEdgeTo(h25, 0);
        h25.CreateEdgeTo(m37, 0);
        m37.CreateEdgeTo(d20, 0);
        d20.CreateEdgeTo(m37, 0);


        /* Vapur İskeleleri*/
        y15.CreateEdgeTo(v1, 1);          /*Üçkuyular Vapur İskelesi - Tramvay.Üçkuyular Meydan*/
        v1.CreateEdgeTo(y15, 1);          /*Üçkuyular Vapur İskelesi - Tramvay.Üçkuyular Meydan*/


        v1.CreateEdgeTo(v8, 22);          /*Üçkuyular Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v8.CreateEdgeTo(v1, 22);          /*Üçkuyular Vapur İskelesi - Bostanlı Vapur İskelesi*/

        y13.CreateEdgeTo(v2, 0);          /*Güzelyalı Vapur İskelesi - Güzelyalı Tramvay*/
        v2.CreateEdgeTo(y13, 0);          /*Güzelyalı Vapur İskelesi - Güzelyalı Tramvay*/


        v2.CreateEdgeTo(v3, 5);           /*Güzelyalı Vapur İskelesi - Konak Vapur İskelesi*/
        v3.CreateEdgeTo(v2, 5);           /*Güzelyalı Vapur İskelesi - Konak Vapur İskelesi*/


        v5.CreateEdgeTo(v2, 15);          /*Güzelyalı Vapur İskelesi - Alsancak Vapur İskelesi*/
        v2.CreateEdgeTo(v5, 15);          /*Güzelyalı Vapur İskelesi - Alsancak Vapur İskelesi*/

        v7.CreateEdgeTo(v2, 23);          /*Güzelyalı Vapur İskelesi - Karşıyaka Vapur İskelesi*/
        v2.CreateEdgeTo(v7, 23);          /*Güzelyalı Vapur İskelesi - Karşıyaka Vapur İskelesi*/

        v8.CreateEdgeTo(v3, 12);          /*Konak Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v3.CreateEdgeTo(v8, 12);          /*Konak Vapur İskelesi - Bostanlı Vapur İskelesi*/

        v7.CreateEdgeTo(v3, 13);          /*Konak Vapur İskelesi - Karşıyaka Vapur İskelesi*/
        v3.CreateEdgeTo(v7, 13);          /*Konak Vapur İskelesi - Karşıyaka Vapur İskelesi*/

        v3.CreateEdgeTo(v6, 21);          /*Konak Vapur İskelesi - Bayraklı Vapur İskelesi*/
        v6.CreateEdgeTo(v3, 21);          /*Konak Vapur İskelesi - Bayraklı Vapur İskelesi*/

        v3.CreateEdgeTo(v4, 4);           /*Konak Vapur İskelesi - Pasaport Vapur İskelesi*/
        v4.CreateEdgeTo(v3, 4);           /*Konak Vapur İskelesi - Pasaport Vapur İskelesi*/

        v5.CreateEdgeTo(v3, 8);           /*Konak Vapur İskelesi - Alsancak Vapur İskelesi*/
        v3.CreateEdgeTo(v5, 8);           /*Konak Vapur İskelesi - Alsancak Vapur İskelesi*/

        f22.CreateEdgeTo(v3, 1);          /*Konak Vapur İskelesi - Konak Aktarma Merkezi(((((((((((((((((walking.d))))))))))))*/
        v3.CreateEdgeTo(f22, 1);          /*Konak Vapur İskelesi - Konak Aktarma Merkezi(((((((((((((((((walking.d))))))))))))*/


        f21.CreateEdgeTo(v3, 0);          /*Konak Vapur İskelesi - 302.İskele*/
        v3.CreateEdgeTo(f21, 0);          /*Konak Vapur İskelesi - 302.İskele*/


        v4.CreateEdgeTo(v5, 4);           /*Pasaport Vapur İskelesi - Alsancak Vapur İskelesi*/
        v5.CreateEdgeTo(v4, 4);           /*Pasaport Vapur İskelesi - Alsancak Vapur İskelesi*/

        v7.CreateEdgeTo(v4, 11);          /*Pasaport Vapur İskelesi - Karşıyaka Vapur İskelesi*/
        v4.CreateEdgeTo(v7, 11);          /*Pasaport Vapur İskelesi - Karşıyaka Vapur İskelesi*/

        v4.CreateEdgeTo(v8, 13);          /*Pasaport Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v8.CreateEdgeTo(v4, 13);          /*Pasaport Vapur İskelesi - Bostanlı Vapur İskelesi*/

        v4.CreateEdgeTo(y6, 1);           /*Pasaport Vapur İskelesi - Tramvay.Gazi Bulvarı(((((((((((((walking.d)))))))))))))))*/
        y6.CreateEdgeTo(v4, 1);           /*Pasaport Vapur İskelesi - Tramvay.Gazi Bulvarı(((((((((((((walking.d)))))))))))))))*/


        v5.CreateEdgeTo(v6, 10);          /*Alsancak Vapur İskelesi - Bayraklı Vapur İskelesi*/
        v6.CreateEdgeTo(v5, 10);          /*Alsancak Vapur İskelesi - Bayraklı Vapur İskelesi*/

        v7.CreateEdgeTo(v5, 8);           /*Alsancak Vapur İskelesi - Karşıyaka Vapur İskelesi*/
        v5.CreateEdgeTo(v7, 8);           /*Alsancak Vapur İskelesi - Karşıyaka Vapur İskelesi*/


        v5.CreateEdgeTo(v8, 15);          /*Alsancak Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v8.CreateEdgeTo(v5, 15);          /*Alsancak Vapur İskelesi - Bostanlı Vapur İskelesi*/


        v5.CreateEdgeTo(e17, 1);          /*Alsancak Vapur İskelesi - Alsancak Gar(((((((((((((((((walking.d))))))))))))))))))*/
        e17.CreateEdgeTo(v5, 1);          /*Alsancak Vapur İskelesi - Alsancak Gar(((((((((((((((((walking.d))))))))))))))))))*/
        v6.CreateEdgeTo(i8, 0);           /*Bayraklı Vapur İskelesi - Bayraklı Üst Geçit(((((((((((((walking.d)))))))))))))))*/
        i8.CreateEdgeTo(v6, 0);           /*Bayraklı Vapur İskelesi - Bayraklı Üst Geçit(((((((((((((walking.d)))))))))))))))*/
        v7.CreateEdgeTo(v8, 12);          /*Karşıyaka Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v8.CreateEdgeTo(v7, 12);          /*Karşıyaka Vapur İskelesi - Bostanlı Vapur İskelesi*/

        v3.CreateEdgeTo(v8, 15);          /*Konak Vapur İskelesi - Bostanlı Vapur İskelesi*/
        v8.CreateEdgeTo(v3, 15);          /*Konak Vapur İskelesi - Bostanlı Vapur İskelesi*/


        /*Tekli Bağlantı Noktaları*/
        d11.CreateEdgeTo(w14, 0);          /*681.Hakim Evleri - Metro.Hatay*/
        w14.CreateEdgeTo(d11, 0);          /*681.Hakim Evleri - Metro.Hatay*/

        p14.CreateEdgeTo(m18, 0);          /*İzban.Erbaş - 691.Ege Serbest Bölge 2*/
        m18.CreateEdgeTo(p14, 0);          /*İzban.Erbaş - 691.Ege Serbest Bölge 2*/


        m20.CreateEdgeTo(p15, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/
        p15.CreateEdgeTo(m20, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/


        m20.CreateEdgeTo(m20, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/
        p15.CreateEdgeTo(p15, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/


        m20.CreateEdgeTo(p15, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/
        p15.CreateEdgeTo(m20, 0);          /*İzban.Semt Garajı - 691.Gaziemir Semt Garajı*/

        p19.CreateEdgeTo(f18, 0);          /*İzban.Kemer - 302.Kemer*/
        f18.CreateEdgeTo(p19, 0);          /*İzban.Kemer - 302.Kemer*/

        p19.CreateEdgeTo(f18, 0);          /*İzban.Kemer - 302.Kemer*/
        f18.CreateEdgeTo(p19, 0);          /*İzban.Kemer - 302.Kemer*/

        p19.CreateEdgeTo(f18, 0);          /*İzban.Kemer - 302.Kemer*/
        f18.CreateEdgeTo(p19, 0);          /*İzban.Kemer - 302.Kemer*/


        f19.CreateEdgeTo(w9, 0);           /*302.Basmane Gar - Metro.Basmane Gar*/
        w9.CreateEdgeTo(f19, 0);           /*302.Basmane Gar - Metro.Basmane Gar*/

        g1.CreateEdgeTo(h1, 3);            /*304- 470 Ortak durakları*/
        h1.CreateEdgeTo(g1, 3);            /*304- 470 Ortak durakları*/

        g2.CreateEdgeTo(h2, 3);
        h2.CreateEdgeTo(g2, 3);

        g2.CreateEdgeTo(h2, 3);
        h2.CreateEdgeTo(g2, 3);

        g3.CreateEdgeTo(h3, 3);
        h3.CreateEdgeTo(g3, 3);


        g4.CreateEdgeTo(h4, 3);
        h4.CreateEdgeTo(g4, 3);

        g6.CreateEdgeTo(h6, 3);
        h6.CreateEdgeTo(g6, 3);


        h7.CreateEdgeTo(h7, 3);
        g7.CreateEdgeTo(g7, 3);

        g8.CreateEdgeTo(h8, 3);
        h8.CreateEdgeTo(g8, 3);

        g9.CreateEdgeTo(h9, 3);
        h9.CreateEdgeTo(g9, 0);

        h10.CreateEdgeTo(g10, 0);
        g10.CreateEdgeTo(h10, 3);

        h11.CreateEdgeTo(g11, 3);
        g11.CreateEdgeTo(h11, 3);

        g12.CreateEdgeTo(h12, 3);
        h12.CreateEdgeTo(g12, 3);

        g12.CreateEdgeTo(h12, 3);
        h12.CreateEdgeTo(g12, 3);

        g13.CreateEdgeTo(h13, 3);
        h13.CreateEdgeTo(g13, 3);

        h14.CreateEdgeTo(g14, 3);
        g14.CreateEdgeTo(h14, 3);

        h15.CreateEdgeTo(g15, 3);
        g15.CreateEdgeTo(h15, 3);

        w1.CreateEdgeTo(e1, 5);        /*Metro.Evka_3 - 963.Evka 3 Aktarma Merkezi(((((((((((((((((((((((((((((((walking))))))))))*/
        e1.CreateEdgeTo(w1, 2);        /*Metro.Evka_3 - 963.Evka 3 Aktarma Merkezi(((((((((((((((((((((((((((((((walking))))))))))*/

        p26.CreateEdgeTo(p26, 1);      /*912.Naldöken - İzban.Naldöken*/
        j19.CreateEdgeTo(j19, 1);      /*912.Naldöken - İzban.Naldöken*/

        p27.CreateEdgeTo(x14, 0);      /*İzban.Alaybey - Tramvay.Alaybey*/
        x14.CreateEdgeTo(p27, 0);      /*İzban.Alaybey - Tramvay.Alaybey*/

        x1.CreateEdgeTo(p32, 0);       /*Tramvay.Mavişehir - İzban.Mavişehir*/
        p32.CreateEdgeTo(x1, 0);       /*Tramvay.Mavişehir - İzban.Mavişehir*/

        i4.CreateEdgeTo(k4, 0);        /*921.Muammer Aksoy Parkı - 543.Muammer Aksoy Parkı*/
        k4.CreateEdgeTo(i4, 0);        /*921.Muammer Aksoy Parkı - 543.Muammer Aksoy Parkı*/

        i5.CreateEdgeTo(k5, 0);        /*921.Selçuk_Yaşar_İÖO - 543.Selçuk_Yaşar_İÖO*/
        k5.CreateEdgeTo(i5, 0);        /*921.Selçuk_Yaşar_İÖO - 543.Selçuk_Yaşar_İÖO*/

        i6.CreateEdgeTo(k6, 0);        /*921.Tersane - 543.Tersane*/
        k6.CreateEdgeTo(i6, 0);        /*921.Tersane - 543.Tersane*/

        i4.CreateEdgeTo(k4, 0);        /*921.Muammer Aksoy Parkı - 543.Muammer Aksoy Parkı*/
        k4.CreateEdgeTo(i4, 0);        /*921.Muammer Aksoy Parkı - 543.Muammer Aksoy Parkı*/

        n16.CreateEdgeTo(m32, 0);      /*680.Yağhaneler 3 - 691.Yağhaneler 3*/
        m32.CreateEdgeTo(n16, 0);      /*680.Yağhaneler 3 - 691.Yağhaneler 3*/

//       graph.plot_graph(graph);
        return graph;
    }

    public static Graph insertVertices(Graph graph) {
        /*777 Numaralı Otobüs Hattı Bağlantıları*/

        graph.InsertVertex(a1);
        graph.InsertVertex(a2);
        graph.InsertVertex(a3);
        graph.InsertVertex(a4);
        graph.InsertVertex(a5);
        graph.InsertVertex(a6);
        graph.InsertVertex(a7);
        graph.InsertVertex(a8);
        graph.InsertVertex(a9);
        graph.InsertVertex(a10);
        graph.InsertVertex(a11);
        graph.InsertVertex(a12);
        graph.InsertVertex(a13);
        graph.InsertVertex(a14);
        graph.InsertVertex(a15);
        graph.InsertVertex(a16);
        graph.InsertVertex(a17);
        graph.InsertVertex(a18);
        graph.InsertVertex(a19);
        graph.InsertVertex(a20);
        graph.InsertVertex(a21);
        graph.InsertVertex(a22);
        graph.InsertVertex(a23);
        graph.InsertVertex(a24);
        graph.InsertVertex(a25);


        /*969 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(b1);
        graph.InsertVertex(b2);
        graph.InsertVertex(b3);
        graph.InsertVertex(b4);
        graph.InsertVertex(b5);
        graph.InsertVertex(b6);
        graph.InsertVertex(b7);
        graph.InsertVertex(b8);
        graph.InsertVertex(b9);
        graph.InsertVertex(b10);
        graph.InsertVertex(b11);
        graph.InsertVertex(b12);
        graph.InsertVertex(b13);
        graph.InsertVertex(b14);


//        /*551 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(c1);
        graph.InsertVertex(c2);
        graph.InsertVertex(c3);
        graph.InsertVertex(c4);
        graph.InsertVertex(c5);
        graph.InsertVertex(c6);
        graph.InsertVertex(c7);
        graph.InsertVertex(c8);
        graph.InsertVertex(c9);
        graph.InsertVertex(c10);
        graph.InsertVertex(c11);
        graph.InsertVertex(c12);
        graph.InsertVertex(c13);
        graph.InsertVertex(c14);
        graph.InsertVertex(c15);
        graph.InsertVertex(c16);
        graph.InsertVertex(c17);
        graph.InsertVertex(c18);
        graph.InsertVertex(c19);
        graph.InsertVertex(c20);
        graph.InsertVertex(c21);
        graph.InsertVertex(c22);
        graph.InsertVertex(c23);
        graph.InsertVertex(c24);
        graph.InsertVertex(c25);
        graph.InsertVertex(c26);
        graph.InsertVertex(c27);
        graph.InsertVertex(c28);
        graph.InsertVertex(c29);
        graph.InsertVertex(c30);

        /*681 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(d1);
        graph.InsertVertex(d2);
        graph.InsertVertex(d3);
        graph.InsertVertex(d4);
        graph.InsertVertex(d5);
        graph.InsertVertex(d6);
        graph.InsertVertex(d7);
        graph.InsertVertex(d8);
        graph.InsertVertex(d9);
        graph.InsertVertex(d10);
        graph.InsertVertex(d11);
        graph.InsertVertex(d12);
        graph.InsertVertex(d13);
        graph.InsertVertex(d14);
        graph.InsertVertex(d15);
        graph.InsertVertex(d16);
        graph.InsertVertex(d17);
        graph.InsertVertex(d18);
        graph.InsertVertex(d19);
        graph.InsertVertex(d20);
        graph.InsertVertex(d21);


        /*963 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(e1);
        graph.InsertVertex(e2);
        graph.InsertVertex(e3);
        graph.InsertVertex(e4);
        graph.InsertVertex(e5);
        graph.InsertVertex(e6);
        graph.InsertVertex(e7);
        graph.InsertVertex(e8);
        graph.InsertVertex(e9);
        graph.InsertVertex(e10);
        graph.InsertVertex(e11);
        graph.InsertVertex(e12);
        graph.InsertVertex(e13);
        graph.InsertVertex(e14);
        graph.InsertVertex(e15);
        graph.InsertVertex(e16);
        graph.InsertVertex(e17);
        graph.InsertVertex(e18);
        graph.InsertVertex(e19);


        /*302 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(f1);
        graph.InsertVertex(f2);
        graph.InsertVertex(f3);
        graph.InsertVertex(f4);
        graph.InsertVertex(f5);
        graph.InsertVertex(f6);
        graph.InsertVertex(f7);
        graph.InsertVertex(f8);
        graph.InsertVertex(f9);
        graph.InsertVertex(f10);
        graph.InsertVertex(f11);
        graph.InsertVertex(f12);
        graph.InsertVertex(f13);
        graph.InsertVertex(f14);
        graph.InsertVertex(f15);
        graph.InsertVertex(f16);
        graph.InsertVertex(f17);
        graph.InsertVertex(f18);
        graph.InsertVertex(f19);
        graph.InsertVertex(f20);
        graph.InsertVertex(f21);
        graph.InsertVertex(f22);

        /*304 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(g1);
        graph.InsertVertex(g2);
        graph.InsertVertex(g3);
        graph.InsertVertex(g4);
        graph.InsertVertex(g5);
        graph.InsertVertex(g6);
        graph.InsertVertex(g7);
        graph.InsertVertex(g8);
        graph.InsertVertex(g9);
        graph.InsertVertex(g10);
        graph.InsertVertex(g11);
        graph.InsertVertex(g12);
        graph.InsertVertex(g13);
        graph.InsertVertex(g14);
        graph.InsertVertex(g15);
        graph.InsertVertex(g16);
        graph.InsertVertex(g17);
        graph.InsertVertex(g18);
        graph.InsertVertex(g19);


        /*470 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(h1);
        graph.InsertVertex(h2);
        graph.InsertVertex(h3);
        graph.InsertVertex(h4);
        graph.InsertVertex(h5);
        graph.InsertVertex(h6);
        graph.InsertVertex(h7);
        graph.InsertVertex(h8);
        graph.InsertVertex(h9);
        graph.InsertVertex(h10);
        graph.InsertVertex(h11);
        graph.InsertVertex(h12);
        graph.InsertVertex(h13);
        graph.InsertVertex(h14);
        graph.InsertVertex(h15);
        graph.InsertVertex(h16);
        graph.InsertVertex(h17);
        graph.InsertVertex(h18);
        graph.InsertVertex(h19);
        graph.InsertVertex(h20);
        graph.InsertVertex(h21);
        graph.InsertVertex(h22);
        graph.InsertVertex(h23);
        graph.InsertVertex(h24);
        graph.InsertVertex(h25);
        graph.InsertVertex(h26);


        /*921 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(i1);
        graph.InsertVertex(i2);
        graph.InsertVertex(i3);
        graph.InsertVertex(i4);
        graph.InsertVertex(i5);
        graph.InsertVertex(i6);
        graph.InsertVertex(i7);
        graph.InsertVertex(i8);
        graph.InsertVertex(i9);
        graph.InsertVertex(i10);


        /*912 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(j1);
        graph.InsertVertex(j2);
        graph.InsertVertex(j3);
        graph.InsertVertex(j4);
        graph.InsertVertex(j5);
        graph.InsertVertex(j6);
        graph.InsertVertex(j7);
        graph.InsertVertex(j8);
        graph.InsertVertex(j9);
        graph.InsertVertex(j10);
        graph.InsertVertex(j11);
        graph.InsertVertex(j12);
        graph.InsertVertex(j13);
        graph.InsertVertex(j14);
        graph.InsertVertex(j15);
        graph.InsertVertex(j16);
        graph.InsertVertex(j17);
        graph.InsertVertex(j18);
        graph.InsertVertex(j19);
        graph.InsertVertex(j20);
        graph.InsertVertex(j21);
        graph.InsertVertex(j22);
        graph.InsertVertex(j23);

        /*543 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(k1);
        graph.InsertVertex(k2);
        graph.InsertVertex(k3);
        graph.InsertVertex(k4);
        graph.InsertVertex(k5);
        graph.InsertVertex(k6);
        graph.InsertVertex(k7);
        graph.InsertVertex(k8);
        graph.InsertVertex(k9);
        graph.InsertVertex(k10);
        graph.InsertVertex(k11);
        graph.InsertVertex(k12);
        graph.InsertVertex(k13);
        graph.InsertVertex(k14);
        graph.InsertVertex(k15);
        graph.InsertVertex(k16);
        graph.InsertVertex(k17);
        graph.InsertVertex(k18);
        graph.InsertVertex(k19);
        graph.InsertVertex(k20);
        graph.InsertVertex(k21);
        graph.InsertVertex(k22);

        /*680 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(n1);
        graph.InsertVertex(n2);
        graph.InsertVertex(n3);
        graph.InsertVertex(n4);
        graph.InsertVertex(n5);
        graph.InsertVertex(n6);
        graph.InsertVertex(n7);
        graph.InsertVertex(n8);
        graph.InsertVertex(n9);
        graph.InsertVertex(n10);
        graph.InsertVertex(n11);
        graph.InsertVertex(n12);
        graph.InsertVertex(n13);
        graph.InsertVertex(n14);
        graph.InsertVertex(n15);
        graph.InsertVertex(n16);
        graph.InsertVertex(n17);
        graph.InsertVertex(n18);
        graph.InsertVertex(n19);
        graph.InsertVertex(n20);
        graph.InsertVertex(n21);
        graph.InsertVertex(n22);

        /*691 Numaralı Otobüs Hattı Bağlantıları*/
        graph.InsertVertex(m1);
        graph.InsertVertex(m2);
        graph.InsertVertex(m3);
        graph.InsertVertex(m4);
        graph.InsertVertex(m5);
        graph.InsertVertex(m6);
        graph.InsertVertex(m7);
        graph.InsertVertex(m8);
        graph.InsertVertex(m9);
        graph.InsertVertex(m10);
        graph.InsertVertex(m11);
        graph.InsertVertex(m12);
        graph.InsertVertex(m13);
        graph.InsertVertex(m14);
        graph.InsertVertex(m15);
        graph.InsertVertex(m16);
        graph.InsertVertex(m17);
        graph.InsertVertex(m18);
        graph.InsertVertex(m19);
        graph.InsertVertex(m20);
        graph.InsertVertex(m21);
        graph.InsertVertex(m22);
        graph.InsertVertex(m23);
        graph.InsertVertex(m24);
        graph.InsertVertex(m25);
        graph.InsertVertex(m26);
        graph.InsertVertex(m27);
        graph.InsertVertex(m28);
        graph.InsertVertex(m29);
        graph.InsertVertex(m30);
        graph.InsertVertex(m31);
        graph.InsertVertex(m32);
        graph.InsertVertex(m33);
        graph.InsertVertex(m34);
        graph.InsertVertex(m35);
        graph.InsertVertex(m36);
        graph.InsertVertex(m37);
        graph.InsertVertex(m38);

        /* Karşıyaka Tramvay Hattı Durakları*/
        graph.InsertVertex(x1);
        graph.InsertVertex(x2);
        graph.InsertVertex(x3);
        graph.InsertVertex(x4);
        graph.InsertVertex(x5);
        graph.InsertVertex(x6);
        graph.InsertVertex(x7);
        graph.InsertVertex(x8);
        graph.InsertVertex(x9);
        graph.InsertVertex(x10);
        graph.InsertVertex(x11);
        graph.InsertVertex(x12);
        graph.InsertVertex(x13);
        graph.InsertVertex(x14);

        /* Konak Tramvay Hattı Durakları */
        graph.InsertVertex(y1);
        graph.InsertVertex(y2);
        graph.InsertVertex(y3);
        graph.InsertVertex(y4);
        graph.InsertVertex(y5);
        graph.InsertVertex(y6);
        graph.InsertVertex(y7);
        graph.InsertVertex(y8);
        graph.InsertVertex(y9);
        graph.InsertVertex(y10);
        graph.InsertVertex(y11);
        graph.InsertVertex(y12);
        graph.InsertVertex(y3);
        graph.InsertVertex(y14);
        graph.InsertVertex(y15);
        graph.InsertVertex(y16);

        /* Metro Durakları */
        graph.InsertVertex(w1);
        graph.InsertVertex(w2);
        graph.InsertVertex(w3);
        graph.InsertVertex(w4);
        graph.InsertVertex(w5);
        graph.InsertVertex(w6);
        graph.InsertVertex(w7);
        graph.InsertVertex(w8);
        graph.InsertVertex(w9);
        graph.InsertVertex(w10);
        graph.InsertVertex(w11);
        graph.InsertVertex(w12);
        graph.InsertVertex(w13);
        graph.InsertVertex(w14);
        graph.InsertVertex(w15);
        graph.InsertVertex(w16);
        graph.InsertVertex(w17);

        /* İzban Durakları */
        graph.InsertVertex(p1);
        graph.InsertVertex(p2);
        graph.InsertVertex(p3);
        graph.InsertVertex(p4);
        graph.InsertVertex(p5);
        graph.InsertVertex(p6);
        graph.InsertVertex(p7);
        graph.InsertVertex(p8);
        graph.InsertVertex(p9);
        graph.InsertVertex(p10);
        graph.InsertVertex(p11);
        graph.InsertVertex(p12);
        graph.InsertVertex(p13);
        graph.InsertVertex(p14);
        graph.InsertVertex(p15);
        graph.InsertVertex(p16);
        graph.InsertVertex(p17);
        graph.InsertVertex(p18);
        graph.InsertVertex(p19);
        graph.InsertVertex(p20);
        graph.InsertVertex(p21);
        graph.InsertVertex(p22);
        graph.InsertVertex(p23);
        graph.InsertVertex(p24);
        graph.InsertVertex(p25);
        graph.InsertVertex(p26);
        graph.InsertVertex(p27);
        graph.InsertVertex(p28);
        graph.InsertVertex(p29);
        graph.InsertVertex(p30);
        graph.InsertVertex(p31);
        graph.InsertVertex(p32);
        graph.InsertVertex(p33);
        graph.InsertVertex(p34);
        graph.InsertVertex(p35);
        graph.InsertVertex(p36);
        graph.InsertVertex(p37);
        graph.InsertVertex(p38);
        graph.InsertVertex(p39);
        graph.InsertVertex(p40);
        graph.InsertVertex(p41);

        graph.InsertVertex(v1);
        graph.InsertVertex(v2);
        graph.InsertVertex(v3);
        graph.InsertVertex(v4);
        graph.InsertVertex(v5);
        graph.InsertVertex(v6);
        graph.InsertVertex(v7);
        graph.InsertVertex(v8);

        return graph;
    }
}

