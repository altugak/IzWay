package com.ozyilmaz.izway.core


class PathOption(
    source: Station,
    destination: Station,
    path: List<Station>,
    duration: Int
) {
    val source: Station = source
    val destination: Station = destination
    val path: List<Station> = path
    val duration: Int = duration
}