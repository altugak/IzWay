package com.ozyilmaz.izway

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import io.reactivex.Completable

class MainActivity : AppCompatActivity(), OnMapReadyCallback, LocationListener,
    GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    /*  //38.439055, 27.141252, //alsancak vapur iskelesi
                //38.454058, 27.097359, //bostnali vapur iskelesi
                38.491175, 26.963689,
                // 38.418727, 27.125276,
                //38.439152, 27.141236 alsancakvapur iskelesi
                //izmir ekonomi üniversitesi
                */
    private val MOCK_STARTLOCATION: Pair<Double, Double> = Pair(38.388389, 27.045124)
    private lateinit var dataSwitch: Switch
    lateinit var manager: GraphManager
    private var text_search_location: TextView? = null
    private lateinit var text_result_ways: TextView
    private val PERMISSION_ID = 42
    lateinit var mFusedLocationClient: FusedLocationProviderClient
    private var mMap: GoogleMap? = null
    private lateinit var mLastLocation: Location
    private var mCurrLocationMarker: Marker? = null
    private var mGoogleApiClient: GoogleApiClient? = null
    private lateinit var mLocationRequest: LocationRequest
    lateinit var spinner: ProgressBar

    lateinit var lv: ListView
    lateinit var al: ArrayList<String>
    lateinit var aa: ArrayAdapter<String>
    var resultOptions = ArrayList<String>()
    lateinit var activity: Activity// reference to an Activity

    var destination: Pair<Double, Double>? = null
    var currentLocation: Location? = null

    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.setBackgroundDrawableResource(R.mipmap.yellow_icon_foreground)

        spinner = findViewById(R.id.progressBar1)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        text_search_location = findViewById(R.id.searchLocation)
        text_result_ways = findViewById(R.id.result)

        val btnGetCurrentLocation = findViewById<Button>(R.id.getCurrentLocation)
        val btnGoLocation = findViewById<Button>(R.id.goLocation)
        lv = findViewById(R.id.resultListView)
        al = ArrayList()
        al.add(0, "Option 1")
        al.add(1, "Option 2")
        al.add(2, "Option 3")
        aa = ArrayAdapter(this, android.R.layout.simple_list_item_1, al)
        lv.adapter = aa
        lv.isClickable = false
        lv.setOnItemClickListener { parent, view, position, id ->
            text_result_ways.text = resultOptions.get(position)
        }
        dataSwitch = findViewById(R.id.sync)

        text_result_ways.movementMethod = ScrollingMovementMethod()

        btnGetCurrentLocation.setOnClickListener {
            Toast.makeText(
                this@MainActivity,
                "Getting Current Location",
                Toast.LENGTH_SHORT
            )
                .show()

            getLastLocation()
        }
        manager = GraphManager(applicationContext)
        manager.prepareGraph().doOnComplete {
            btnGoLocation.setOnClickListener {
                spinner.visibility = View.VISIBLE
                text_result_ways.text = ""
                performGoLocationClick()
            }

            // Set an checked change listener for switch button
            dataSwitch.setOnCheckedChangeListener { buttonView, isChecked ->

                if (isChecked) {
                    val toast = Toast.makeText(
                        this,
                        "Started Updating Data on Telephone",
                        Toast.LENGTH_LONG
                    )
                    toast.show()

                    manager.updateData()
                        .doOnComplete {
                            val toast = Toast.makeText(
                                this,
                                "Updating Operation Completed",
                                Toast.LENGTH_LONG
                            )
                            toast.show()
                            val handler = Handler()
                            handler.postDelayed(Runnable { toast.cancel() }, 10000)
                        }
                        .subscribe()

                }
            }
        }.subscribe()
    }

    private fun performGoLocationClick() {

        println("Finding shortest path " + text_search_location?.text)
        //destination = manager.searchLocation(text_search_location?.text.toString(),null)
        Completable.fromRunnable {
            spinner.visibility = View.VISIBLE
        }.andThen {
            manager.process(
                MOCK_STARTLOCATION.first, MOCK_STARTLOCATION.second,
                //currentLocation?.latitude, currentLocation?.longitude
                text_search_location?.text.toString()
            )!!.subscribe {
                lv.isClickable = true
                if (it != null && it.size > 0) {
                    resultOptions = ArrayList()
                    resultOptions.addAll(it)
                    resultOptions.add("Options Not Found")
                    resultOptions.add("Options Not Found")
                    resultOptions.add("Options Not Found")
                    text_result_ways.text = resultOptions[0]
                }
                //                Toast.makeText(
                //                    this,
                //                    "Options are generated u can click and see",
                //                    Toast.LENGTH_SHORT
                //                ).show()
                spinner.visibility = View.GONE
            }
        }.subscribe()
    }

    override fun onConnected(bundle: Bundle?) {

        mLocationRequest = LocationRequest()
        mLocationRequest.interval = 1000
        mLocationRequest.fastestInterval = 1000
        mLocationRequest.priority = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            LocationServices.getFusedLocationProviderClient(this)
        }
    }

    override fun onConnectionSuspended(i: Int) {

    }

    override fun onLocationChanged(location: Location) {

        mLastLocation = location
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker!!.remove()
        }
        //Place current location marker
        val latLng = LatLng(location.latitude, location.longitude)
        val markerOptions = MarkerOptions()
        markerOptions.position(latLng)
        markerOptions.title("Current Position")
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
        mCurrLocationMarker = mMap!!.addMarker(markerOptions)

        //move map camera
        mMap!!.moveCamera(CameraUpdateFactory.newLatLng(latLng))
        mMap!!.animateCamera(CameraUpdateFactory.zoomTo(11f))

        //stop location updates
        if (mGoogleApiClient != null) {
            LocationServices.getFusedLocationProviderClient(this)
        }

    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                buildGoogleApiClient()
                mMap!!.isMyLocationEnabled = true
            }
        } else {
            buildGoogleApiClient()
            mMap!!.isMyLocationEnabled = true
        }

    }


    @SuppressLint("MissingPermission")
    private fun getLastLocation(): Pair<Double?, Double?> {
        if (checkPermissions()) {
            if (isLocationEnabled()) {

                mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
                    currentLocation = task.result
                    if (currentLocation == null) {
                        requestNewLocationData()
                    } else {
                        findViewById<TextView>(R.id.latTextView).text =
                            currentLocation!!.latitude.toString()
                        findViewById<TextView>(R.id.lonTextView).text =
                            currentLocation!!.longitude.toString()
                    }
                }
                return Pair(currentLocation?.latitude, currentLocation?.longitude)

            } else {
                Toast.makeText(this, "Turn on location", Toast.LENGTH_LONG).show()
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            }
        } else {
            requestPermissions()
        }
        return Pair(0.0, 0.0)
    }

    @Synchronized
    private fun buildGoogleApiClient() {
        mGoogleApiClient = GoogleApiClient.Builder(this)
            .addConnectionCallbacks(this)
            .addOnConnectionFailedListener(this)
            .addApi(LocationServices.API).build()
        mGoogleApiClient!!.connect()
    }

    @SuppressLint("MissingPermission")
    private fun requestNewLocationData() {
        var mLocationRequest = LocationRequest()
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest.interval = 0
        mLocationRequest.fastestInterval = 0
        mLocationRequest.numUpdates = 1

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        mFusedLocationClient.requestLocationUpdates(
            mLocationRequest, mLocationCallback,
            Looper.myLooper()
        )
    }

    private val mLocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            var mLastLocation: Location = locationResult.lastLocation
            findViewById<TextView>(R.id.latTextView).text = mLastLocation.latitude.toString()
            findViewById<TextView>(R.id.lonTextView).text = mLastLocation.longitude.toString()
        }
    }

    private fun isLocationEnabled(): Boolean {
        var locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

    private fun checkPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_ID
        )
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        if (requestCode == PERMISSION_ID) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                getLastLocation()
            }
        }
    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {

    }
}
