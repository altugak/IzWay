package com.ozyilmaz.izway.core;

public class Station {
    private int id;
    private String info;
    private TransportationType type;
    private String station;
    private double latitude;
    private double longitude;

    public Station(int id, String info, TransportationType type, String station, double latitude, double longitude) {
        this.id = id;
        this.info = info;
        this.type = type;
        this.station = station;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Station() {

    }

    public static Station from(Vertex vertex, double lat, double longi) {
        return new Station(vertex.getId(), vertex.getInfo(), vertex.getType(), vertex.getName(), lat, longi);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public TransportationType getType() {
        return type;
    }

    public void setType(TransportationType type) {
        this.type = type;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }


}
