package com.ozyilmaz.izway.core;

import android.util.Pair;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Graph implements Cloneable {
    public List<Vertex> getVertices() {
        return vertices;
    }

    private List<Vertex> vertices;

    private boolean directed;

    public Graph(boolean directed) {
        vertices = new ArrayList<>();
        this.directed = directed;
    }

    private Graph(Graph g) {
        this.directed = g.directed;
        this.vertices = new LinkedList<>();
        this.vertices.addAll(g.vertices);
    }

    public void InsertVertex(Vertex vertex) {
        vertices.add(vertex);
    }

    public Pair<List<Vertex>, List<Double>> shortest_path(Vertex source, Vertex desination) {

        HashMap<Vertex, Double> dist = new HashMap<>();
        HashMap<Vertex, Vertex> pred = new HashMap<>();

        dijkstra(source, dist, pred);

        List<Vertex> pathList = new ArrayList<>();
        List<Double> distanceList = new ArrayList<>();
        Vertex vertex = desination;
        pathList.add(desination);
        if (vertex != null) {
            while (source.getId() != vertex.getId()) {
                if (pred.get(vertex) != null)
                    vertex = pred.get(vertex);
                pathList.add(vertex);
                distanceList.add(dist.get(vertex));

                if (pathList.size() > 100) {
                    return Pair.create(pathList, distanceList);
                }
            }
        }
        Collections.reverse(pathList);

        return Pair.create(pathList, distanceList);
    }

    public Graph clone() {
        return new Graph(this);
    }

    public void dijkstra(Vertex start, HashMap<Vertex, Double> dist, HashMap<Vertex, Vertex> pred) {
        HashSet<Vertex> notProcessed = new HashSet<>(vertices.size());

        for (Vertex v : vertices) {
            dist.put(v, Double.POSITIVE_INFINITY);
            notProcessed.add(v);
        }

        dist.put(start, 0.0);

        while (notProcessed.size() > 0) {
            Vertex closest = null;

            double min = Double.POSITIVE_INFINITY;
            for (Map.Entry<Vertex, Double> d : dist.entrySet()) {
                if (notProcessed.contains(d.getKey()) && d.getValue() < min) {
                    closest = d.getKey();
                    min = d.getValue();
                }
            }
            notProcessed.remove(closest);

            Double currentDist = dist.get(closest);
            if (closest != null) {
                for (Edge edge : closest.getEdges()) {
                    Vertex v2 = edge.getV2();
                    Double distWithWeight = currentDist + edge.getWeight();
                    if (!dist.containsKey(v2) || dist.get(v2) > distWithWeight) {
                        dist.put(v2, distWithWeight);
                        pred.put(v2, closest);
                    }
                }
            } else
                return;

        }
    }

}
