package com.ozyilmaz.izway.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Vertex implements Cloneable {

    public Map<Integer, List<Vertex>> getShortestPath() {
        return shortestPath;
    }

    public void setShortestPath(Map<Integer, List<Vertex>> shortestPath) {
        this.shortestPath = shortestPath;
    }

    public Map<Integer, List<Vertex>> shortestPath = new HashMap<>();

    public int getId() {
        return id;
    }

    public TransportationType getType() {
        return type;
    }

    public String getInfo() {
        return info;
    }

    public void setEdges(ArrayList<Edge> edges) {
        this.edges = edges;
    }

    private int id;
    private TransportationType type;
    private String info;
    private List<Edge> edges;

    private String name;

    public Vertex clone() {
        return new Vertex(id, name, type, info);
    }

    public Vertex() {

    }

    public Vertex(int id, String name, TransportationType type, String info) {
        this.name = name;
        this.id = id;
        this.type = type;
        this.info = info;
        edges = new ArrayList<Edge>();

    }

    public void CreateEdgeTo(Vertex v2, double weight) {
        edges.add(new Edge(this, v2, weight));
    }

    public void CreateEdgeTo(Vertex to) {
        CreateEdgeTo(to, 1.0f);
    }

    public void RemoveEdge(Vertex to) {
        Iterator<Edge> it = edges.iterator();
        while (it.hasNext()) {
            Edge edge = it.next();
            if (edge.IsConnecting(to)) {
                it.remove();
            }
        }
    }

    public boolean HasAConnection(Vertex v) {
        for (Edge edge : edges) {
            if (edge.IsConnecting(v)) {
                return true;
            }
        }
        return false;
    }

    public boolean IsLeaf() {
        return edges.isEmpty();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Edge> getEdges() {
        return edges;
    }

    public static Vertex to(Station station) {
        return new Vertex(station.getId(), station.getStation(), station.getType(), station.getInfo());
    }

    public static List<Station> to(List<Vertex> path, List<Station> stations) {
        List<Station> result = new ArrayList();
        if (path != null && path.size() > 0) {
            for (Vertex vertex : path) {
                Station s = stations.get(vertex.id);
                result.add(new Station(vertex.getId(), s.getInfo(), vertex.type, vertex.name, s.getLatitude(), s.getLongitude()));

            }
        }

        return result;
    }
}