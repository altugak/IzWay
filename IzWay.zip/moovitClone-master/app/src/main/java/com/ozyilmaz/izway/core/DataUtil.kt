package com.ozyilmaz.izway.core

import android.content.ContentValues.TAG
import android.util.Log
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase
import io.reactivex.Observable

class DataUtil {
    var DB_NAME = "points"
    var DB_RECORD_NAME = "point"
    var db: FirebaseDatabase? = Firebase.database

    fun getDb() {
        db = FirebaseDatabase.getInstance()
    }

    fun syncToCloudPointData(stations: ArrayList<Station>) {
        // Write a message to the database
        val myRef = db!!.getReference(DB_NAME)

        stations.parallelStream().forEach {
            val myRefChild = myRef.child(DB_RECORD_NAME + it.id)
            myRefChild.setValue(it)
        }
    }

    fun retrieveDataFromCloud(): Observable<ArrayList<Station>> {
        val stations = ArrayList<Station>()
        var dataListener =
            db!!.getReference(DB_NAME).addChildEventListener(object : ChildEventListener {
                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                    TODO("Not yet implemented")
                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                }

                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    val value = snapshot.getValue<Station>()
                    if (value != null) {
                        stations.add(value)
                        Log.d(TAG, "Value is: $value")
                    }
                }

                override fun onChildRemoved(snapshot: DataSnapshot) {
                    TODO("Not yet implemented")
                }

            })


        /*
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException())
            }*/

        return Observable.just(stations)
    }
}

